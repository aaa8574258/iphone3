//
//  FoodCommonViewController.m
//  360du
//
//  Created by linghang on 15-4-18.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "FoodCommonViewController.h"
#import "CommomFoodModel.h"
#import "CommonFoodCell.h"
#import "AFNetworkTwoPackaging.h"
#import "NSString+URLEncoding.h"
#import "FoodListCategoryModel.h"
#import "FoodMerchantListViewController.h"
#import "CommonFoodFourBtnHead.h"
#import "LocationModel.h"
#import "NSString+URLEncoding.h"
#import "FileOperation.h"
#import "MJRefresh.h"
#import "UIScrollView+MJRefresh.h"
#import "MJRefreshHeaderView.h"
#import "MJRefreshBaseView.h"
#import "FoodBussinessListCollectionViewController.h"
#define COMMOMFOODCELL @"commonFoodCell"
@interface FoodCommonViewController ()<UITableViewDataSource,UITableViewDelegate,MBProgressHUDDelegate>{
    MJRefreshHeaderView *_header;
    MJRefreshBaseView *_baseView;
}
@property(nonatomic,copy)NSString *titleName;
@property(nonatomic,copy)NSString *urlString;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,strong)NSMutableArray *itemArr;
@property(nonatomic,weak)UITableView *tableView;
@property(nonatomic,assign)NSInteger allHeight;
@property(nonatomic,copy)NSString *communtityId;//小区Id
@property(nonatomic,assign)NSInteger sortNum;//默认排序
@property(nonatomic,assign)NSInteger categoryId;//分类Id
@property(nonatomic,strong)NSMutableArray *stateArr;
//上边四个按钮
@property(nonatomic,strong)NSMutableArray *fourHeadBtnArr;
@property(nonatomic,copy)NSString *category;
@property(nonatomic,copy)NSString *sort;
@property(nonatomic,copy)NSString *welfare;
@property(nonatomic,copy)NSString *communtity;
@property(nonatomic,strong)CommonFoodFourBtnHead *fourBtnHead;
@property(nonatomic,strong)NSMutableArray *fourHeadStateArr;//表示四种状态
@property(nonatomic,strong)NSArray *communtityArr;//小区总数
@property(nonatomic,copy)NSString *loactionCommuntity;//经纬度
@property(nonatomic,strong)AFHTTPRequestOperationManager *rom;
@property(nonatomic,copy)NSString *cityName;//城市名称
@property(nonatomic,assign)NSInteger pageNum;
@property(nonatomic,assign)NSInteger pageSize;
@property(nonatomic,strong)MBProgressHUD *hudProgress;
@end

@implementation FoodCommonViewController
-(id)initWithTitleName:(NSString *)titleName andNSString:(NSString *)urlString andCommuntityId:(NSString *)communtityId andSortNum:(NSInteger)sortNum andCatergoryId:(NSInteger)categoryId andCommuntityArr:(NSArray *)communtityArr andLoaction:(NSString *)locationStr andCityName:(NSString *)cityName{
    self = [super init];
    if (self) {
        [self makeInit];
        self.titleName = titleName;
        self.urlString = urlString;
        self.sortNum = sortNum;
        self.communtityId = communtityId;
        self.categoryId = categoryId;
        self.cityName = cityName;
        self.loactionCommuntity = locationStr;
        
        
        if (communtityArr.count != 0) {
            [self regainReguestXqid];
            self.communtityArr = communtityArr;
        }else{
            [self loadCommuntity];
        }
       //[self loadData];
        //1&xqid=86420010000004&sort=1&gotoPage=1&pageSize=2
               [self makeUI];
        [self makeHUd];
    }
    return self;
}
//加载图片
-(void)makeHUd{
    self.hudProgress = [[MBProgressHUD alloc] initWithView:self.view];
    self.hudProgress.delegate = self;
    //self.hudProgress.color = [UIColor clearColor];
    self.hudProgress.labelText = @"loading";
    self.hudProgress.dimBackground = YES;
    //self.hudProgress.margin = 80.f;
    //self.hudProgress.yOffset = 150.f;
    [self.view addSubview:self.hudProgress];
    [self.hudProgress showWhileExecuting:@selector(myProgressTask) onTarget:self withObject:nil animated:YES];
}

#pragma mark 先加载小区
-(void)loadCommuntity{
    self.rom = [AFHTTPRequestOperationManager manager];
    self.rom.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/json",@"text/html",@"text/plain",@"application/json",nil];
    NSString *url = [[NSString stringWithFormat:COMMUNITYDATA,self.cityName,self.loactionCommuntity] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    url = @"http://211.152.8.99/360duang/serviceServlet?serviceName=dlshopmag&medthodName=dlshoplist&codename=2&xqid=86420010000004&sort=1&gotoPage=1&pageSize=5";
    [self.rom GET: url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSMutableArray *tempArr = [NSMutableArray arrayWithCapacity:0];
        
        for (NSDictionary *temp in responseObject[@"buzdata"]) {
            LocationModel *model = [[LocationModel alloc] initWithDictionary:temp];
            [tempArr addObject:model];
        }
        if ([responseObject[@"buzdata"] count] != 0) {
            self.communtityArr = tempArr;
        }
        [self loadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        //[[NSURLCache sharedURLCache] removeAllCachedResponses];
#warning message
        NSLog(@"%@",error);
    }];

}
-(void)viewWillAppear:(BOOL)animated{
        [self makeNav];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;

    // Do any additional setup after loading the view.
}
-(void)makeInit{
    self.dataArr = [NSMutableArray arrayWithCapacity:0];
    self.itemArr = [NSMutableArray arrayWithCapacity:0];
    self.stateArr = [NSMutableArray arrayWithCapacity:0];
    self.fourHeadBtnArr = [NSMutableArray arrayWithCapacity:0];
    self.fourHeadStateArr = [NSMutableArray arrayWithCapacity:0];
    for (NSInteger i = 0; i < 4; i++) {
        [self.fourHeadBtnArr addObject:@"0"];
        [self.fourHeadStateArr addObject:@"0"];
    }
   // Xqid:@"86420010000004" andCodeName:@"1" andSort:@"1"
    self.category = @"1";
    self.sort = @"1";
    self.welfare = @"";
    self.communtity = @"86420010000004";
    self.pageNum = 1;
    self.pageSize = 5;
    
    //[self requestHead:3];
}
-(void)loadData{
#warning message 测试四个按钮btn
    //[self requestHead:0];
    //[self requestHead:1];
    //[self requestHead:2];
    AFHTTPRequestOperationManager *manger = [AFHTTPRequestOperationManager manager];
    manger.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/json",@"text/html",@"application/json",@"text/plain",nil];
    manger.requestSerializer = [[AFHTTPRequestSerializer alloc] init];
    manger.responseSerializer = [[AFHTTPResponseSerializer alloc] init];
    //NSString *url = [NSString stringWithFormat:STUDY_CATEGORY_ITEM,self.categoryId,22];
    // manger.operationQueue addOperation:<#(NSOperation *)#>
    [manger GET:@"http://211.152.8.99/360duang/serviceServlet?serviceName=dlshopmag&medthodName=dlshoplist&codename=2&xqid=86420010000004&sort=1&gotoPage=1&pageSize=5" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self hudWasHidden:self.hudProgress];
        NSString *str = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSData *backData = [str dataUsingEncoding:NSUTF8StringEncoding];
        NSError *error = nil;
        
        NSDictionary *tempStr = [NSJSONSerialization JSONObjectWithData:backData options:NSJSONReadingMutableLeaves error:&error];
        if (error) {
            NSLog(@"%@",error);
        }
#warning message responseObject
        NSLog(@"%@",tempStr);
NSLog(@"%@",tempStr[@"buzdata"]);
        NSLog(@"%@",self.dataArr);
        for (NSDictionary *temp in tempStr[@"buzdata"]) {
            CommomFoodModel *model = [[CommomFoodModel alloc] initWithDictionary:temp]
            ;
            NSMutableArray *itemArr = [NSMutableArray arrayWithCapacity:0];
            for (NSDictionary *itemTemp in temp[@"yhdetail"]) {
                CommomDetailFoodModel *detailFood = [[CommomDetailFoodModel alloc] initWithDictionary:itemTemp];
                [itemArr addObject:detailFood];
            }
            [self.itemArr addObject:itemArr];
            [self.dataArr addObject:model];
        }
        for (NSInteger i = 0; i < self.dataArr.count; i++) {
            [self.stateArr addObject:@"0"];
        }
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        [[NSURLCache sharedURLCache] removeAllCachedResponses];
                [self hudWasHidden:self.hudProgress];
        NSLog(@"%@",[error description]);
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"警告" message:@"网络不流畅，请换个网络试试" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确认", nil];
        [alertView show];
        return ;
    }];
}
-(void)makeNav{
    [self setNavBarImage:@"landi.png"];
    //[self setBackgroud:@"lantiao x.png"];
    [self setBackImageStateName:@"fanhuijian02.png" AndHighlightedName:@""];
    
    
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectZero];
    //view.backgroundColor = MAINVIEWNAVBARCOLOR;
    //[self.view addSubview:view];
    
    UILabel *lable = [[UILabel alloc] initWithFrame:CGRectZero];
    lable.text = self.titleName;
    lable.font = [UIFont systemFontOfSize:16 * self.numSingleVesion];
    lable.textColor = [UIColor whiteColor];
    [lable sizeToFit];
    lable.frame = CGRectMake(5 * self.numSingleVesion, 0 + (44 - 15) / 2, lable.frame.size.width, 15);
    [view addSubview:lable];
    view.frame = CGRectMake(0, 0, lable.frame.size.width, 44);
    //UIBarButtonItem *centerBar = [[UIBarButtonItem alloc] initWithCustomView:view];
    self.navigationItem.titleView = view;
}
-(void)makeUI{
    [self makeFourBtn];
    [self makeTable];
    [self addFooter];
}
-(void)makeTable{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, self.allHeight + 5 * self.numSingleVesion, WIDTH_CONTROLLER, HEIGHT_CONTROLLER - self.allHeight - 5 * self.numSingleVesion) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];
    tableView.showsVerticalScrollIndicator = NO;
    [tableView registerClass:[CommonFoodCell class] forCellReuseIdentifier:COMMOMFOODCELL];
    self.tableView = tableView;
    //上拉下拉刷新
    //实例化header和footer
    _header = [MJRefreshHeaderView header];
//    _baseView = [MJRefreshBaseView ]
}
-(void)makeFourBtn{
    NSArray *btnTitleArr = @[@"分类",@"排序",@"福利",@"附近小区"];
//    [UIImage imageNamed:@"xing01"];
    CGFloat everWidth = (WIDTH_CONTROLLER - 3 * self.numSingleVesion)/ 4;
    for (NSInteger i = 0; i < btnTitleArr.count; i++) {
        UIButton *btnCategory = [UIButton buttonWithType:UIButtonTypeCustom];
        btnCategory.frame = CGRectMake((everWidth + 1 * self.numSingleVesion) * i, 64, everWidth, 40 * self.numSingleVesion);
        [btnCategory setTitle:btnTitleArr[i] forState:UIControlStateNormal];
        [btnCategory addTarget:self action:@selector(fourBtnTitleDown:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btnCategory];
        [btnCategory setTitleColor:COMMONFOODTITLEBTNCOLOR forState:UIControlStateNormal];
        btnCategory.titleLabel.textAlignment = NSTextAlignmentCenter;
        btnCategory.tag = 1300 + i;
        
        UIImageView *lineImg = [[UIImageView alloc] initWithFrame:CGRectMake(everWidth + (everWidth + 1 * self.numSingleVesion) * i, 64, 1 * self.numSingleVesion, 40 * self.numSingleVesion)];
        lineImg.image = [UIImage imageNamed:@"line.jpg"];
        [self.view addSubview:lineImg];
    }
    UIImageView *horineLine = [[UIImageView alloc] initWithFrame:CGRectMake(0, 64 + 40 * self.numSingleVesion, WIDTH_CONTROLLER, 1 * self.numSingleVesion)];
    [self.view addSubview:horineLine];
    horineLine.image = [UIImage imageNamed:@"line_1.jpg"];
    
    UIImageView *btnImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 64 + 40 * self.numSingleVesion + 1 * self.numSingleVesion, WIDTH_CONTROLLER, 60 * self.numSingleVesion)];
    btnImg.image = [UIImage imageNamed:@"landi.png"];
    [self.view addSubview:btnImg];
    CGFloat imgHeight = [VersionTranlate returnImageHeightImgname:@"wenzi.png" andWidth:WIDTH_CONTROLLER - (10 + 50) * self.numSingleVesion];
    UIImageView *btnLableImg = [[UIImageView alloc] initWithFrame:CGRectMake(10 * self.numSingleVesion, (60 - imgHeight) / 2, WIDTH_CONTROLLER - (10 + 50) * self.numSingleVesion, imgHeight)];
    btnLableImg.image = [UIImage imageNamed:@"wenzi.png"];
    [btnImg addSubview:btnLableImg];
    
    self.allHeight = 64 + 40 * self.numSingleVesion + 1 * self.numSingleVesion + 60 * self.numSingleVesion;
}
-(void)fourBtnTitleDown:(UIButton *)fourBtnTitle{
    for (id temp in self.fourBtnHead.subviews) {
        [temp removeFromSuperview];
    }
    [self.fourBtnHead removeFromSuperview];
    if ([self.fourHeadStateArr[fourBtnTitle.tag - 1300] isEqualToString:@"0"]) {
        for (NSInteger i = 0; i < self.fourHeadStateArr.count; i++) {
            [self.fourHeadStateArr replaceObjectAtIndex:i withObject:@"0"];
        }
        [self requestHead:fourBtnTitle.tag - 1300];
        [self.fourHeadStateArr replaceObjectAtIndex:fourBtnTitle.tag - 1300 withObject:@"1"];
    }else{
        //[self requestHead:fourBtnTitle.tag - 1300];
        [self.fourHeadStateArr replaceObjectAtIndex:fourBtnTitle.tag - 1300 withObject:@"0"];
    }
    
    
}
#pragma mark tableview的协议代理
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArr.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CommomFoodModel *model = self.dataArr[indexPath.row];
    if (model.yhdetail.count != 0) {
        if ([self.stateArr[indexPath.row] isEqualToString:@"0"]) {
            return 80 * self.numSingleVesion;
        }else{
            return model.yhdetail.count * 40 * self.numSingleVesion + 80 * self.numSingleVesion;
        }
        
    }
    return 60 * self.numSingleVesion;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CommonFoodCell *cell = [tableView dequeueReusableCellWithIdentifier:COMMOMFOODCELL forIndexPath:indexPath];
    if (self.dataArr.count != 0) {
         CommomFoodModel *model = self.dataArr[indexPath.row];
        cell.target = self;
        cell.row = indexPath.row;
        if (model.yhdetail.count != 0) {
            //self.itemArr
            cell.privilegeArr = model.yhdetail;
#warning message 
            NSLog(@"%@",model.yhdetail);
        }
        if([self.stateArr[indexPath.row] isEqualToString:@"1"]){
            cell.privilegeBtnState = YES;
        }else{
            cell.privilegeBtnState = NO;
        }
        [cell makeUI];
        

       
        [cell refreshUI:model];
    }
    
    
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CommomFoodModel *model = self.dataArr[indexPath.row];
#warning message
    NSLog(@"%@",model.did);
//    FoodMerchantListViewController *merchant = [[FoodMerchantListViewController alloc] initWithId:model.did];
//    [self.navigationController pushViewController:merchant animated:YES];
    FoodBussinessListCollectionViewController *merchant = [[FoodBussinessListCollectionViewController alloc] initWithId:model.did];
    [self.navigationController pushViewController:merchant animated:YES];
}
#pragma mark //tableviewCell返回的按钮的东西
-(void)returnTicketAndPay:(NSString *)payAndTicket{
    
}
//点击优惠详情
-(void)returnPrivilege:(NSInteger)row{
    if ([self.stateArr[row] isEqualToString:@"0"]) {
        [self.stateArr replaceObjectAtIndex:row withObject:@"1"];
    }else{
        [self.stateArr replaceObjectAtIndex:row withObject:@"0"];
    }
    [self.tableView reloadData];
}

#pragma mark 返回每一行的高度
//-(CGFloat)retunRowHeight:(NSInteger)num{
//    
//    
//}
#pragma mark 头标各种分类
-(void)requestHead:(NSInteger)num{
    if (![self.fourHeadBtnArr[num] isEqual:@"0"]) {
        self.fourBtnHead = [[CommonFoodFourBtnHead alloc] initWithFrame:CGRectMake(0, 64 + 40 * self.numSingleVesion, WIDTH_CONTROLLER, 40 * self.numSingleVesion * [self.fourHeadBtnArr[num] count]) andNSArray:self.fourHeadBtnArr[num] andNum:num];
        [self.view addSubview:self.fourBtnHead];
        return;
    }
    NSMutableArray *tempArr = [NSMutableArray arrayWithCapacity:0];
    AFNetworkTwoPackaging *twoPackaging = [[AFNetworkTwoPackaging alloc] init];
    
    switch (num) {
        case 0:{
#warning message
            NSLog(@"%@",MERCHANTLISTCATEGORY);
            [twoPackaging getUrl: MERCHANTLISTCATEGORY andFinishBlock:^(id getResult) {
#warning message
                NSLog(@"head0:%@",getResult);
                for (NSInteger i = [getResult count] - 1; i >= 0; i--) {
                    FoodListCategoryModel *model = [[FoodListCategoryModel alloc] initWithDictionary:getResult[i]];
                    [tempArr addObject:model];
                }
                [self.fourHeadBtnArr replaceObjectAtIndex:num withObject:tempArr];
                [self createFourHeadUI:num andNSArray:self.fourHeadBtnArr[num]];
                
            }];
            break;
        }
        case 1:{
           // [self loadJson];
            AFHTTPRequestOperationManager *manger = [AFHTTPRequestOperationManager manager];
            manger.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/json",@"text/html",@"application/json",@"text/plain",nil];
            manger.requestSerializer = [[AFHTTPRequestSerializer alloc] init];
            manger.responseSerializer = [[AFHTTPResponseSerializer alloc] init];
            //NSString *url = [NSString stringWithFormat:STUDY_CATEGORY_ITEM,self.categoryId,22];
            // manger.operationQueue addOperation:<#(NSOperation *)#>
            NSString *url = [NSString stringWithFormat:@"http://211.152.8.99/360duang/360du/sort.json"];
            url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [manger GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
#warning message
                NSLog(@"%@",responseObject);
                NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
                NSString *pathFinal = [FileOperation createCacheFile:@"sort" andPath:@"sort" andDocument:path];
                NSError *error = nil;
                //[responseObject writeToFile:pathFinal atomically:YES encoding:NSUTF8StringEncoding error:&error];
                [FileOperation storeCacheDataFile:@"sort" andPath:@"sort" andFileData:responseObject andDocument:path];
                if (error) {
                    NSLog(@"%@",error);
                }else{
                    NSString* content = [[NSString alloc] initWithContentsOfFile:pathFinal encoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingWindowsHebrew) error:&error];
                    if (error) {
                        NSLog(@"%@",error);
                    }
                    else{
                        NSLog(@"%@",content);
                        content = [content stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
                        content = [content stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                        content = [content stringByReplacingOccurrencesOfString:@"\t" withString:@""];
                   // NSString *encodedString = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,(CFStringRef)content,(CFStringRef)@"!$&'()*+,-./:;=?@_~%#[]",NULL,kCFStringEncodingUTF8));
                        NSString *encodedString = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,(CFStringRef)content,(CFStringRef)@"!$&'()*+-.:=?@_~%#",NULL,kCFStringEncodingUTF8));
#warning message
                        NSLog(@"%@",content);
                        NSLog(@"%@",encodedString);
                    NSData *finaData = [encodedString dataUsingEncoding:NSUTF8StringEncoding];
                    NSArray *array = [NSJSONSerialization JSONObjectWithData:finaData options:NSJSONReadingMutableLeaves error:nil];
#warning message
                    NSLog(@"array:%@",array);
                    }
//                    NSData *str1 = [FileOperation readCacheDataFile:@"sort" andPath:@"sort" andDocument:path];
//                    NSLog(@"%@",str1);
//                   NSString *str2 =  [[NSString alloc] initWithData:str1 encoding:NSUTF8StringEncoding];
//                    NSLog(@"str2%@",str2);
//                    NSString *str = [[NSString alloc] initWithContentsOfFile:pathFinal encoding:NSUTF8StringEncoding error:&error];
//                    if (error) {
//                        NSLog(@"%@",error);
//                    }else{
//                        NSLog(@"%@",str);
//                    }
                }
#warning message
                NSString *str = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
               NSString *str1 =  [[NSMutableString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
#warning message
                NSLog(@"%@",str1);
               // str
#warning message
                NSLog(@"%@",str);
                NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
                NSArray *tempStr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
#warning message
                NSLog(@"%@",tempStr);
                for (NSInteger i = 0; i < [tempStr count]; i++) {
                    FoodListCategoryModel *model = [[FoodListCategoryModel alloc] initWithDictionary:tempStr[i]];
                    [tempArr addObject:model];
                }

                [self.fourHeadBtnArr replaceObjectAtIndex:num withObject:tempArr];
                [self createFourHeadUI:num andNSArray:self.fourHeadBtnArr[num]];
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                [[NSURLCache sharedURLCache] removeAllCachedResponses];
                NSLog(@"%@",[error description]);
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"警告" message:@"网络不流畅，请换个网络试试" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确认", nil];
                [alertView show];
                return ;
            }];
           break;
        }
        case 2:{
            [twoPackaging getUrl: MERCHANTLISTWELFARE andFinishBlock:^(id getResult) {
#warning message
                NSLog(@"head2:%@",getResult);
                for (NSInteger i = 0; i < [getResult count]; i++) {
                    FoodListCategoryModel *model = [[FoodListCategoryModel alloc] initWithDictionary:getResult[i]];
                    [tempArr addObject:model];
                }
                [self.fourHeadBtnArr replaceObjectAtIndex:num withObject:tempArr];
                [self createFourHeadUI:num andNSArray:self.fourHeadBtnArr[num]];
            }];
            break;
        }
        case 3:{
            AFHTTPRequestOperationManager *manger = [AFHTTPRequestOperationManager manager];
            manger.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/json",@"text/html",@"application/json",@"text/plain",nil];
            manger.requestSerializer = [[AFHTTPRequestSerializer alloc] init];
            manger.responseSerializer = [[AFHTTPResponseSerializer alloc] init];
            //NSString *url = [NSString stringWithFormat:STUDY_CATEGORY_ITEM,self.categoryId,22];
            // manger.operationQueue addOperation:<#(NSOperation *)#>
            NSString *url = [NSString stringWithFormat:@"http://211.152.8.99/360duang/serviceServlet?serviceName=findmap&medthodName=xqlist&cityName=%@&location=116.459777,39.869332&gotoPage=1&pageSize=4",@"北京市"];
            url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [manger GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {

                NSString *str = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];

                NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
                NSDictionary *tempStr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
                for (NSDictionary *temp in tempStr[@"buzdata"]) {
                    LocationModel *model = [[LocationModel alloc] initWithDictionary:temp];
                    [tempArr addObject:model];
                }
                [self.fourHeadBtnArr replaceObjectAtIndex:num withObject:tempArr];
                [self createFourHeadUI:num andNSArray:self.fourHeadBtnArr[num]];
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                [[NSURLCache sharedURLCache] removeAllCachedResponses];
                NSLog(@"%@",[error description]);
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"警告" message:@"网络不流畅，请换个网络试试" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确认", nil];
                [alertView show];
                return ;
            }];

            break;
        }
        default:
            break;
    }
}
//创建四个界面
- (void)createFourHeadUI:(NSInteger)num andNSArray:(NSArray *)array{
    self.fourBtnHead = [[CommonFoodFourBtnHead alloc] initWithFrame:CGRectMake(0, 64 + 40 * self.numSingleVesion, WIDTH_CONTROLLER, 40 * self.numSingleVesion * array.count) andNSArray:self.fourHeadBtnArr[num] andNum:num];
    self.fourBtnHead.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:self.fourBtnHead];
}
//请求数据
-(void)regainReguestXqid{
    self.pageNum = 1;
    self.pageSize = 5;
    AFNetworkTwoPackaging *twoPackaging = [[AFNetworkTwoPackaging alloc] init];
//    "serviceServlet?serviceName=dlshopmag&medthodName=dlshoplist&codename=%@&xqid=%d&sort=%d&gotoPage=%d&pageSize=%d"
   NSString *url = [NSString stringWithFormat:MERCHANTLIST,[NSString stringWithFormat:@"%ld",(long)self.categoryId],self.communtityId.integerValue,self.sortNum,self.pageNum,self.pageSize];
    url = @"http://211.152.8.99/360duang/serviceServlet?serviceName=dlshopmag&medthodName=dlshoplist&codename=2&xqid=86420010000004&sort=1&gotoPage=1&pageSize=5";
    [twoPackaging getUrl:url andFinishBlock:^(id getResult) {
#warning message
        NSLog(@"%@",getResult);
        [self.tableView headerEndRefreshing];
       // [self hudWasHidden:self.hudProgress];
        //[self.dataArr removeAllObjects];
        //[self.itemArr removeAllObjects];
        //先清空，后者刷新
        for (NSDictionary *temp in getResult[@"buzdata"]) {
            CommomFoodModel *model = [[CommomFoodModel alloc] initWithDictionary:temp]
            ;
            NSMutableArray *itemArr = [NSMutableArray arrayWithCapacity:0];
            for (NSDictionary *itemTemp in temp[@"yhdetail"]) {
                CommomDetailFoodModel *detailFood = [[CommomDetailFoodModel alloc] initWithDictionary:itemTemp];
                [itemArr addObject:detailFood];
            }
            [self.itemArr addObject:itemArr];
            [self.dataArr addObject:model];
        }
        for (NSInteger i = 0; i < self.dataArr.count; i++) {
            [self.stateArr addObject:@"0"];
        }
        [self.tableView reloadData];

    }];
    
}
#pragma mark 下拉刷新
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (self.tableView.contentOffset.y < -20) {
        [self.dataArr removeAllObjects];
        [self.itemArr removeAllObjects];
        self.pageNum = 1;
        self.pageSize = 5;
        [self makeHUd];
        [self.tableView addHeaderWithTarget:self action:@selector(regainReguestXqid)];
        self.tableView.headerRefreshingText = @"正在帮你刷新";
        [self.tableView headerBeginRefreshing];
    }
    if (self.tableView.contentOffset.y > self.tableView.contentSize.height + 40) {
        self.pageSize++;
        [self.tableView addFooterWithTarget:self action:@selector(regainReguestXqid)];
        self.tableView.footerRefreshingText = @"正在加载";
        [self.tableView footerBeginRefreshing];
    }
}
- (void)addFooter
{
//    __unsafe_unretained typeof(self) vc = self;
//    // 添加上拉刷新尾部控件
//    [self.tableView addFooterWithCallback:^{
//        // 进入刷新状态就会回调这个Block
//        [self.tableView addFooterWithTarget:self action:@selector(regainReguestXqid)];
//        self.tableView.footerRefreshingText = @"正在加载";
//        [self.tableView footerBeginRefreshing];
//    }];
}
#pragma mark HUD的代理方法,关闭HUD时执行
-(void)hudWasHidden:(MBProgressHUD *)hud
{
    [hud removeFromSuperview];
    hud = nil;
}
-(void) myProgressTask{
    float progress = 0.0f;
    while (progress < 1.0f) {
        progress += 0.01f;
        self.hudProgress.progress = progress;
        usleep(50000);
    }
    
}

#pragma mark 下载json
-(void)loadJson{
    AFNetworkTwoPackaging *twoPackaging = [[AFNetworkTwoPackaging alloc] init];
    //    "serviceServlet?serviceName=dlshopmag&medthodName=dlshoplist&codename=%@&xqid=%d&sort=%d&gotoPage=%d&pageSize=%d"
    NSString *url = [NSString stringWithFormat:MERCHANTLIST,[NSString stringWithFormat:@"%ld",(long)self.categoryId],(long)self.communtityId.integerValue,self.sortNum,self.pageNum,self.pageSize];
    [twoPackaging getUrl:url andFinishBlock:^(id getResult) {
#warning message
        NSLog(@"%@",getResult);
        [self.tableView headerEndRefreshing];
        [self hudWasHidden:self.hudProgress];
        //[self.dataArr removeAllObjects];
        //[self.itemArr removeAllObjects];
        //先清空，后者刷新
        for (NSDictionary *temp in getResult[@"buzdata"]) {
            CommomFoodModel *model = [[CommomFoodModel alloc] initWithDictionary:temp]
            ;
            NSMutableArray *itemArr = [NSMutableArray arrayWithCapacity:0];
            for (NSDictionary *itemTemp in temp[@"yhdetail"]) {
                CommomDetailFoodModel *detailFood = [[CommomDetailFoodModel alloc] initWithDictionary:itemTemp];
                [itemArr addObject:detailFood];
            }
            [self.itemArr addObject:itemArr];
            [self.dataArr addObject:model];
        }
        for (NSInteger i = 0; i < self.dataArr.count; i++) {
            [self.stateArr addObject:@"0"];
        }
        [self.tableView reloadData];
        
    }];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
