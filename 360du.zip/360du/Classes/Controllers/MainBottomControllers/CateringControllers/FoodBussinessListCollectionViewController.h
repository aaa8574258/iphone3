//
//  FoodBussinessListCollectionViewController.h
//  360du
//
//  Created by linghang on 15/7/3.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseViewController.h"
@class FoodMerchatListItemModel;
@interface FoodBussinessListCollectionViewController : BaseViewController
-(id)initWithId:(NSString *)merchantId;
//返回数据
-(void)returnBuyCar:(FoodMerchatListItemModel *)model andAddAndReduce:(NSString *)addAndReduce;
@end
