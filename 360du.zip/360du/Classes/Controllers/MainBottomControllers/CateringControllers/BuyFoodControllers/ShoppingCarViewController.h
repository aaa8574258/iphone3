//
//  ShoppingCarViewController.h
//  360du
//
//  Created by linghang on 15/7/6.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseViewController.h"

@interface ShoppingCarViewController : BaseViewController
-(id)initWithPrice:(NSArray *)priceArr withFrame:(CGRect)frame;
@end
