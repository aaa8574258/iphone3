//
//  BuyFoodCarViewController.m
//  360du
//
//  Created by linghang on 15/7/6.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BuyFoodCarViewController.h"
#import "BuyFoodCarCell.h"
#define BUYFOOFCARCELL @"buyFoodCarCell"
@interface BuyFoodCarViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,weak)UITableView *tableView;
@property(nonatomic,copy)NSString *privelage;
@property(nonatomic,copy)NSString *moneyTotalCount;
//@property(nonatomic,copy)NSString *
@end

@implementation BuyFoodCarViewController
-(id)initWithArr:(NSArray *)array andPrice:(CGFloat)price{
    self = [super init];
    if (self) {
        [self makeInit];
        [self loadData];
        [self makeNav];
        [self makeUI];
    }
    return self;
}
-(void)makeInit{
    self.dataArr = [NSMutableArray arrayWithCapacity:0];
    [self.dataArr addObject:@[@"新增地址"]];
    [self.dataArr addObject:@[@"货到付款",@"百度钱包",@"支付宝等其它支付方式"]];
    [self.dataArr addObject:@[@"送餐时间",@"送餐备注"]];
    [self.dataArr addObject:@[@"代金券"]];
    [self.dataArr addObject:@[@"配送时间",@"配送备注",@"需要发票"]];
    
}
-(void)makeNav{
    [self setNavBarImage:@"landi.png"];
    //[self setBackgroud:@"lantiao x.png"];
    [self setBackImageStateName:@"fanhuijian02.png" AndHighlightedName:@""];
    
    
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectZero];
    //view.backgroundColor = MAINVIEWNAVBARCOLOR;
    //[self.view addSubview:view];
    
    UILabel *lable = [[UILabel alloc] initWithFrame:CGRectZero];
    lable.text = @"提交订单";
    lable.font = [UIFont systemFontOfSize:16 * self.numSingleVesion];
    lable.textColor = [UIColor whiteColor];
    [lable sizeToFit];
    lable.frame = CGRectMake(5 * self.numSingleVesion, 0 + (44 - 15) / 2, lable.frame.size.width, 15);
    [view addSubview:lable];
    view.frame = CGRectMake(0, 0, lable.frame.size.width, 44);
    //UIBarButtonItem *centerBar = [[UIBarButtonItem alloc] initWithCustomView:view];
    self.navigationItem.titleView = view;
}
-(void)loadData{
    
}
-(void)makeUI{
    [self makeTable];
    [self makeBottom];
}
-(void)makeTable{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTH_CONTROLLER, HEIGHT_CONTROLLER - 64) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];
    [tableView registerClass:[BuyFoodCarCell class] forCellReuseIdentifier:BUYFOOFCARCELL];
    tableView.showsVerticalScrollIndicator = NO;
}
-(void)makeBottom{
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, HEIGHT_CONTROLLER - 49 * self.numSingleVesion, WIDTH_CONTROLLER / 4 * 3, 49 * self.numSingleVesion)];
    leftView.backgroundColor = SMSColor(55, 50, 51);;
    [self.view addSubview:leftView];
    
    //优惠
    UILabel *preivielL = [[UILabel alloc] initWithFrame:CGRectMake(5 * self.numSingleVesion, (49 - 15) / 2 * self.numSingleVesion, 60 * self.numSingleVesion, 15 * self.numSingleVesion)];
    preivielL.textColor = [UIColor redColor];
    [leftView addSubview:preivielL];
    preivielL.text = @"以优惠10元";
    preivielL.font = [UIFont systemFontOfSize:12];
    [preivielL sizeToFit];
    preivielL.center = CGPointMake(5 * self.numSingleVesion + preivielL.frame.size.width / 2, 49 / 2 * self.numSingleVesion);
    //价格
    UILabel *priceLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, 15 * self.numSingleVesion)];
    priceLab.text = @"总计￥15元";
    [leftView addSubview:priceLab];
    priceLab.font = [UIFont systemFontOfSize:15];
    priceLab.textColor = [UIColor redColor];
    [priceLab sizeToFit];
    priceLab.center = CGPointMake(WIDTH_CONTROLLER / 4 * 3 - 5 * self.numSingleVesion - priceLab.frame.size.width, 24.5 * self.numSingleVesion);
    //右边确认下单
//    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(WIDTH_CONTROLLER / 4 * 3, HEIGHT_CONTROLLER - 49 * self.numSingleVesion, WIDTH_CONTROLLER / 2, 49 * self.numSingleVesion)];
//    rightView.backgroundColor = [UIColor redColor];
//    [self.view addSubview:rightView];
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(WIDTH_CONTROLLER / 4 * 3, HEIGHT_CONTROLLER - 49 * self.numSingleVesion, WIDTH_CONTROLLER / 4, 49 * self.numSingleVesion);
    rightBtn.backgroundColor = [UIColor redColor];
    [rightBtn setTitle:@"确认下单" forState:UIControlStateNormal];
    [rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    rightBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
    [rightBtn addTarget:self action:@selector(rightBtnDown) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rightBtn];
}
//确认下单
-(void)rightBtnDown{
    
}
#pragma mark tableView的协议代理
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataArr[section] count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    BuyFoodCarCell *cell = [tableView dequeueReusableCellWithIdentifier:BUYFOOFCARCELL forIndexPath:indexPath];
    [cell initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:BUYFOOFCARCELL];
    cell.textLabel.text = self.dataArr[indexPath.section][indexPath.row];
    if(indexPath.row % 2 == 0){
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row];
    }else{
        
    }
    
    return cell;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataArr.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 30 * self.numSingleVesion;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return nil;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
