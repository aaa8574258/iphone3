//
//  BuyFoodCarViewController.h
//  360du
//
//  Created by linghang on 15/7/6.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseViewController.h"

@interface BuyFoodCarViewController : BaseViewController
-(id)initWithArr:(NSArray *)array andPrice:(CGFloat)price;
@end
