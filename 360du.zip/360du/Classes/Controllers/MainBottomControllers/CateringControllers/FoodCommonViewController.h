//
//  FoodCommonViewController.h
//  360du
//
//  Created by linghang on 15-4-18.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseViewController.h"

@interface FoodCommonViewController : BaseViewController
//andCommuntityArr:(NSArray *)communtityArr
-(id)initWithTitleName:(NSString *)titleName andNSString:(NSString *)urlString andCommuntityId:(NSString *)communtityId andSortNum:(NSInteger)sortNum andCatergoryId:(NSInteger)categoryId andCommuntityArr:(NSArray *)communtityArr andLoaction:(NSString *)locationStr andCityName:(NSString *)cityName;
//tableviewCell返回的按钮的东西
-(void)returnTicketAndPay:(NSString *)payAndTicket;
//点击优惠详情
-(void)returnPrivilege:(NSInteger)row;

@end
