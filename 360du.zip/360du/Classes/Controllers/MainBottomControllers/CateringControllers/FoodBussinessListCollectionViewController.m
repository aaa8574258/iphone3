//
//  FoodBussinessListCollectionViewController.m
//  360du
//
//  Created by linghang on 15/7/3.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "FoodBussinessListCollectionViewController.h"
#import "FoodMerchatListModel.h"
#import "CommonBusinessListCollectionViewCell.h"
#import "MerchantDeatilModel.h"
#import "BuyFoodCarViewController.h"
#import "ShoppingCarViewController.h"
#import "ShoplistModel.h"
#define FOODLISTCOLLECTIONCELL @"foodListCollectionCell"
@interface FoodBussinessListCollectionViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,MBProgressHUDDelegate>
@property(nonatomic,copy)NSString *memchantId;
@property(nonatomic,weak)UICollectionView *collectionView;
@property(nonatomic,weak)UIScrollView *scrollView;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,strong)NSMutableArray *sectionArr;
@property(nonatomic,strong)MBProgressHUD *hudProgress;
@property(nonatomic,weak)UILabel *buyNumLable;//左边显示购买几个的数字
@property(nonatomic,weak)UILabel *priceLable;//左边显示价格
@property(nonatomic,weak)UILabel *selectLable;//右边显示选好了得价格
@property(nonatomic,strong)NSMutableArray *buyArr;//已经购买的东西
@property(nonatomic,assign)CGFloat priceAll;
@property(nonatomic,strong)NSMutableArray *shopPriceCountArr;//买的数量
@end

@implementation FoodBussinessListCollectionViewController
-(id)initWithId:(NSString *)merchantId{
    self = [super init];
    if (self) {
        self.memchantId = merchantId;
        [self makeInit];
        [self makeHUd];
        [self loadData];
        
        [self makeNav];
        [self makeUI];
        [self makeBottom];
    }
    return self;
}
-(void)makeInit{
    self.priceAll = 0;
    self.dataArr = [NSMutableArray arrayWithCapacity:0];
    self.sectionArr = [NSMutableArray arrayWithCapacity:0];
    self.buyArr = [NSMutableArray arrayWithCapacity:0];
    self.shopPriceCountArr = [NSMutableArray arrayWithCapacity:0];
    for (NSInteger i = 0; i < 3; i++) {
        [self.dataArr addObject:@"0"];
        [self.sectionArr addObject:@"0"];
    }
}
//导航条
-(void)makeNav{
    [self setNavBarImage:@"landi.png"];
    //[self setBackgroud:@"lantiao x.png"];
    [self setBackImageStateName:@"fanhuijian02.png" AndHighlightedName:@""];
    //商品、商家、评价
    UIView *navView = [[UIView alloc] initWithFrame:CGRectMake(WIDTH_CONTROLLER / 2 - 90 * self.numSingleVesion, 0, 180 * self.numSingleVesion, 44)];
    NSArray *navArr = @[@"商品",@"商家",@"评价"];
    for (NSInteger i = 0; i < navArr.count; i++) {
        UIButton *navBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        navBtn.frame = CGRectMake(60 * self.numSingleVesion * i, 5, 60 * self.numSingleVesion, 34);
        [navBtn setTitle:navArr[i] forState:UIControlStateNormal];
        navBtn.titleLabel.font = [UIFont systemFontOfSize:15 * self.numSingleVesion];
        [navBtn addTarget:self action:@selector(navBtnDown:) forControlEvents:UIControlEventTouchUpInside];
        [navView addSubview:navBtn];
        [navBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        navBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        navBtn.tag = 1200 + i;
        if(i == 0){
            [navBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        }
    }
    navView.center = CGPointMake(WIDTH_CONTROLLER / 2, 22);
    self.navigationItem.titleView = navView;
    //收藏按钮
    UIButton *favoriteBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    favoriteBtn.frame = CGRectMake(WIDTH_CONTROLLER - 0 * self.numSingleVesion - 0 * self.numSingleVesion, 5, 30 * self.numSingleVesion, 34);
    [favoriteBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [favoriteBtn setTitle:@"收藏" forState:UIControlStateNormal];
    favoriteBtn.titleLabel.font = [UIFont systemFontOfSize:15 * self.numSingleVesion];
    [favoriteBtn addTarget:self action:@selector(navBtnDown:) forControlEvents:UIControlEventTouchUpInside];
    favoriteBtn.titleLabel.textAlignment = NSTextAlignmentRight;
    favoriteBtn.tag = 1250;
    UIBarButtonItem *rightBar = [[UIBarButtonItem alloc] initWithCustomView:favoriteBtn];
    self.navigationItem.rightBarButtonItem = rightBar;
}
-(void)navBtnDown:(UIButton *)navBtn{
    if (navBtn.tag <= 1202) {
        for (NSInteger i = 0; i < 3; i++) {
            UIButton *btn = (UIButton *)[self.navigationItem.titleView viewWithTag:1200 + i];
            [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
        [navBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        
         self.collectionView.contentOffset = CGPointMake(WIDTH_CONTROLLER * (navBtn.tag - 1200), 0);
        if ([self.dataArr[navBtn.tag - 1200] isEqual:@"0"]) {
            [self makeHUd];
            [self loadDataNum:navBtn.tag - 1200];
        }else{
           
        }
    }else{
        
    }
//    switch (navBtn.tag) {
//        case 1200:{
//            
//            break;
//        }
//        case 1201:{
//            
//            break;
//        }
//        case 1202:{
//            
//            break;
//        }
//        case 1250:{
//            
//            break;
//        }
//        default:
//            break;
//    }
}
-(void)loadData{
    NSString *url = @"http://211.152.8.99/360duang/serviceServlet?serviceName=dlshopmag&medthodName=dlsprolist&did=38";
    url = [NSString stringWithFormat:@"http://211.152.8.99/360duang/serviceServlet?serviceName=dlshopmag&medthodName=dlsprolist&did=%@",self.memchantId];

    AFNetworkTwoPackaging *twoPageing = [[AFNetworkTwoPackaging alloc] init];
    [twoPageing getUrl:url andFinishBlock:^(id getResult) {
        [self hudWasHidden:self.hudProgress];
        NSMutableArray *sectionArr = [NSMutableArray arrayWithCapacity:0];
        NSMutableArray *itemArrAll = [NSMutableArray arrayWithCapacity:0];
        for (NSDictionary *temp in getResult) {
            FoodMerchatListModel *model = [[FoodMerchatListModel alloc] initWithDictionary:temp];
            [sectionArr addObject:model];
            NSMutableArray *itemArr = [NSMutableArray arrayWithCapacity:0];
            for (NSDictionary *tempItem in model.item) {
                FoodMerchatListItemModel *itemModel = [[FoodMerchatListItemModel alloc] initWithDictionary:tempItem];
                [itemArr addObject:itemModel];
                
            }
            [itemArrAll addObject:itemArr];
            
        }
        [self.dataArr replaceObjectAtIndex:0 withObject:itemArrAll];
        [self.sectionArr replaceObjectAtIndex:0 withObject:sectionArr];
        [self.collectionView reloadData];
}];
}
-(void)makeUI{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    layout.minimumLineSpacing = 0;
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 64, WIDTH_CONTROLLER, HEIGHT_CONTROLLER - 64 - 49 * self.numSingleVesion) collectionViewLayout:layout];
    collectionView.dataSource = self;
    collectionView.delegate = self;
    collectionView.pagingEnabled = YES;
    collectionView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:collectionView];
    collectionView.backgroundColor = [UIColor whiteColor];
    self.collectionView = collectionView;
    
    [collectionView registerClass:[CommonBusinessListCollectionViewCell class] forCellWithReuseIdentifier:FOODLISTCOLLECTIONCELL];
    
}
-(void)makeBottom{
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, HEIGHT_CONTROLLER - 49 * self.numSingleVesion, WIDTH_CONTROLLER / 3*2, 49 * self.numSingleVesion)];
    leftView.backgroundColor = SMSColor(56, 50, 52);
    [self.view addSubview:leftView];
    
    UIImageView *buyImg = [[UIImageView alloc] initWithFrame:CGRectMake(2 * self.numSingleVesion, -1 * self.numSingleVesion, 40 * self.numSingleVesion, 40 * self.numSingleVesion)];
    buyImg.image = [UIImage imageNamed:@"购物车"];
    [leftView addSubview:buyImg];
    
    UIImageView *buyNum = [[UIImageView alloc] initWithFrame:CGRectMake((68 - 16) / 2 * self.numSingleVesion, -2 * self.numSingleVesion, 16 * self.numSingleVesion, 16 * self.numSingleVesion)];
    buyNum.image = [UIImage imageNamed:@"数量色块"];
    [leftView addSubview:buyNum];
    //显示购买几个
    UILabel *buyLableNum = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 12 * self.numSingleVesion, 12 * self.numSingleVesion)];
    buyLableNum.font = [UIFont systemFontOfSize:12];
    buyLableNum.textColor = [UIColor whiteColor];
    buyLableNum.center = CGPointMake(8 * self.numSingleVesion, 8 * self.numSingleVesion);
    [buyNum addSubview:buyLableNum];
    self.buyNumLable = buyLableNum;
    //总共价格
    UILabel *prcieLable = [[UILabel alloc] initWithFrame:CGRectMake(45 * self.numSingleVesion, (49 - 15) / 2 * self.numSingleVesion, WIDTH_CONTROLLER / 3*2 - 45 * self.numSingleVesion, 15 * self.numSingleVesion)];
    prcieLable.textColor = [UIColor whiteColor];
    prcieLable.font = [UIFont systemFontOfSize:14];
    [leftView addSubview:prcieLable];
    self.priceLable = prcieLable;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = leftView.bounds;
    [leftBtn setTitle:@"" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(selectBtnDown:) forControlEvents:UIControlEventTouchUpInside];
    [leftView addSubview:leftBtn];
    leftBtn.tag = 1620;
    
    //右边选好了
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(WIDTH_CONTROLLER / 3*2 , HEIGHT_CONTROLLER - 49 * self.numSingleVesion, WIDTH_CONTROLLER / 3, 49 * self.numSingleVesion)];
    [self.view addSubview:rightView];
    rightView.backgroundColor = SMSColor(230, 62, 61);
    
    UILabel *selectLable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, 15 * self.numSingleVesion)];
    selectLable.textColor = [UIColor whiteColor];
    selectLable.font = [UIFont systemFontOfSize:14];
    [rightView addSubview:selectLable];
    selectLable.text = @"选好了";
    [selectLable sizeToFit];
    selectLable.frame = CGRectMake((rightView.frame.size.width - selectLable.frame.size.width) / 2, (49 - 15) / 2 * self.numSingleVesion, selectLable.frame.size.width, 15 * self.numSingleVesion);
    UIButton *selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    selectBtn.frame = rightView.bounds;
    [selectBtn addTarget:self action:@selector(selectBtnDown:) forControlEvents:UIControlEventTouchUpInside];
    [selectBtn setTitle:@"" forState:UIControlStateNormal];
    [rightView addSubview:selectBtn];
    selectBtn.tag = 1601;
}
-(void)selectBtnDown:(UIButton *)selectBtn{
    if (selectBtn.tag == 1601) {
        BuyFoodCarViewController *buyFood = [[BuyFoodCarViewController alloc] initWithArr:self.buyArr andPrice:self.priceAll];
        [self.navigationController pushViewController:buyFood animated:YES];
    }else{
        ShoppingCarViewController *shopCar = [[ShoppingCarViewController alloc] initWithPrice:[self returnNextArr] withFrame:CGRectMake(0, 64, WIDTH_CONTROLLER, HEIGHT_CONTROLLER - 64 - 49 * self.numSingleVesion)];
        [self.view addSubview:shopCar.view];
        
    }
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    // Do any additional setup after loading the view.
}
#pragma mark collectionViewCell
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 3;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    CommonBusinessListCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:FOODLISTCOLLECTIONCELL forIndexPath:indexPath];
    cell.target = self;
//    for (id temp in cell.subviews) {
//        [temp removeFromSuperview];
//    }
//    [cell init];
//#warning message
//    NSLog(@"%d",indexPath.row);
    if (![self.dataArr[indexPath.row] isEqual:@"0"]) {
        cell.dataArr = self.dataArr[indexPath.row];
        cell.sectionArr = self.sectionArr[indexPath.row];

        [cell makeUINum:indexPath.row];
    }
    
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(WIDTH_CONTROLLER * 3, HEIGHT_CONTROLLER - 64 - 49 * self.numSingleVesion);
}
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    UIEdgeInsets set = {0,0,0,0};
    return set;
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger num = scrollView.contentOffset.x / WIDTH_CONTROLLER;
    for (NSInteger i = 0; i < 3; i++) {
        UIButton *btn = (UIButton *)[self.navigationItem.titleView viewWithTag:1200 + i];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    UIButton *navBtn = (UIButton *)[self.navigationItem.titleView viewWithTag:1200 + num];
    [navBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    if ([self.dataArr[num] isEqual:@"0"]) {
        [self makeHUd];
        [self loadDataNum:navBtn.tag - 1200];
    }
}
-(void)loadDataNum:(NSInteger)num{
    AFNetworkTwoPackaging *twoPage = [[AFNetworkTwoPackaging alloc] init];
    switch (num) {
        case 0:{
            [self loadData];
            break;
        }
        case 1:{
            [twoPage getUrl:[NSString stringWithFormat:MERCHANTLISTDEATIL,self.memchantId] andFinishBlock:^(id getResult) {
                [self hudWasHidden:self.hudProgress];
//                NSMutableArray *tempDataArr = [NSMutableArray arrayWithCapacity:0];
//                for (id temp in getResult) {
                    MerchantDeatilModel *model = [[MerchantDeatilModel alloc] initWithDictionary:getResult];
                   // [tempDataArr addObject:model];
                //}
                [self.dataArr replaceObjectAtIndex:num withObject:model];
                [self.collectionView reloadData];
            }];
            break;
        }
        case 2:{
            
            break;
        }
        default:
            break;
    }
}
#pragma mark 加载动画效果
//加载图片
-(void)makeHUd{
    self.hudProgress = [[MBProgressHUD alloc] initWithView:self.view];
    self.hudProgress.delegate = self;
    //self.hudProgress.color = [UIColor clearColor];
    self.hudProgress.labelText = @"loading";
    self.hudProgress.dimBackground = YES;
    //self.hudProgress.margin = 80.f;
    //self.hudProgress.yOffset = 150.f;
    [self.view addSubview:self.hudProgress];
    [self.hudProgress showWhileExecuting:@selector(myProgressTask) onTarget:self withObject:nil animated:YES];
}
#pragma mark HUD的代理方法,关闭HUD时执行
-(void)hudWasHidden:(MBProgressHUD *)hud
{
    [hud removeFromSuperview];
    hud = nil;
}
-(void) myProgressTask{
    float progress = 0.0f;
    while (progress < 1.0f) {
        progress += 0.01f;
        self.hudProgress.progress = progress;
        usleep(50000);
    }
    
}
#pragma mark 返回数据
-(void)returnBuyCar:(FoodMerchatListItemModel *)model andAddAndReduce:(NSString *)addAndReduce{
    if ([addAndReduce isEqualToString:@"1"]) {
        [self.buyArr addObject:model];
        self.priceAll += model.price.integerValue;
        
        self.priceLable.text = [NSString stringWithFormat:@"共￥%0.2f",self.priceAll];
        
        if (self.buyNumLable.text.length == 0) {
            self.buyNumLable.text = @"1";
        }else{
            //self.buyNumLable.text.integerValue++;
            self.buyNumLable.text = [NSString stringWithFormat:@"%ld",self.buyNumLable.text.integerValue + 1];
        }
    }else{
        [self.buyArr removeObject:model];
        self.priceAll -= model.price.integerValue;
        self.priceLable.text = [NSString stringWithFormat:@"共￥%0.2f",self.priceAll];
        
        if (self.buyNumLable.text.length == 0) {
            self.buyNumLable.text = @"1";
        }else{
            //self.buyNumLable.text.integerValue++;
            self.buyNumLable.text = [NSString stringWithFormat:@"%ld",self.buyNumLable.text.integerValue - 1];
        }
    }
    
}
#pragma mark 整理数据
-(NSArray *)returnNextArr{
    NSMutableArray *tempArr = [NSMutableArray arrayWithCapacity:0];
    NSMutableArray *buyTempArr = [NSMutableArray arrayWithCapacity:0];
    buyTempArr = [self.buyArr mutableCopy];
    for (NSInteger i = 0; i < buyTempArr.count; i++) {
        FoodMerchatListItemModel *model = buyTempArr[i];
        for (NSInteger j = i + 1; j < buyTempArr.count; j++) {
            FoodMerchatListItemModel *tempModel = buyTempArr[j];

            if ([model.name isEqual:tempModel.name]) {
                [buyTempArr removeObject:model];
                i--;
                j--;
            }
        }
    }
#warning message
    NSLog(@"buyTempArr:%@",buyTempArr);
    NSMutableArray *buyFinalTempArr = [self.buyArr mutableCopy];
    if ([buyTempArr isEqual:self.buyArr]) {
        for (NSInteger i = 0; i < buyTempArr.count; i++) {
            FoodMerchatListItemModel *model = buyTempArr[i];
            [tempArr addObject:@{@"count":@"1",@"model":model}];
        }
    }else{
        for (NSInteger i = 0; i < buyTempArr.count; i++) {
            FoodMerchatListItemModel *model = self.buyArr[i];
            NSInteger count = 0;
            for (NSInteger j = 0; j < buyFinalTempArr.count; j++) {
                FoodMerchatListItemModel *temoModel = self.buyArr[j];
                if ([model isEqual:temoModel]) {
                    count++;
                }
            }
            [tempArr addObject:@{@"count":[NSString stringWithFormat:@"%ld",count],@"model":model}];
        }
    }
    return tempArr;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
