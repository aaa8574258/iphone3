//
//  FoodMerchantListViewController.h
//  360du
//
//  Created by linghang on 15/5/16.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseViewController.h"

@interface FoodMerchantListViewController : BaseViewController
-(id)initWithId:(NSString *)merchantId;
@end
