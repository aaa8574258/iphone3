//
//  LocationCommunityViewController.m
//  360du
//
//  Created by linghang on 15-4-11.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "LocationCommunityViewController.h"
#import "LocationModel.h"
#import "AlphabetSort.h"
#import "SelectCityViewController.h"
#import "AFNetworkTwoPackaging.h"
#import "ViewController.h"
#define COMMUNITYLOCATIONCELL @"communityLocationCell"
#define COMMUNITYSEARCHCELL @"communitySearchCell"
@interface LocationCommunityViewController ()<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,weak)UILabel *lineLable;
@property(nonatomic,assign)CGFloat allHieght;
@property(nonatomic,weak)UITableView *tableView;
@property(nonatomic,weak)UITableView *searchTableView;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,strong)NSMutableArray *communtityArr;
@property(nonatomic,strong)NSMutableArray *nearArr;
@property(nonatomic,strong)NSMutableArray *alapterArr;
@property(nonatomic,strong)NSMutableArray *tempAlapter;
@property(nonatomic,strong)NSArray *searchArr;
@end

@implementation LocationCommunityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self makeInit];
    [self loadData];
    [self makeUI];
    //[self makeNav];
    // Do any additional setup after loading the view.
}
-(void)makeInit{
    self.dataArr = [NSMutableArray arrayWithCapacity:0];
    self.communtityArr = [NSMutableArray arrayWithCapacity:0];
    self.nearArr = [NSMutableArray arrayWithCapacity:0];
    self.alapterArr = [NSMutableArray arrayWithCapacity:0];
    self.tempAlapter = [NSMutableArray arrayWithCapacity:0];
    for (int i = 'A'; i <= 'Z' ; i++) {
        [self.alapterArr addObject:[NSString stringWithFormat:@"%c",i]];
    }
    self.tempAlapter = [self.alapterArr mutableCopy];
}
-(void)loadData{
      NSMutableArray *tempCom = [NSMutableArray arrayWithCapacity:0];
    AFNetworkTwoPackaging *twoPageing = [[AFNetworkTwoPackaging alloc] init];
    [twoPageing getUrl:[NSString stringWithFormat:COMMUNITYDATA,@"864201",@"123"] andFinishBlock:^(id getResult) {
        for (NSDictionary *temp in getResult) {
            LocationModel *model = [[LocationModel alloc] initWithDictionary:temp];
            [tempCom addObject:model];
        }
        self.communtityArr =  [[AlphabetSort returnSortArr:tempCom] mutableCopy];
        self.dataArr = [self.communtityArr mutableCopy];
        
        
        for (NSInteger i = 0; i < self.dataArr.count; i++) {
            if ([self.dataArr[i] count] == 0) {
                [self.dataArr removeObjectAtIndex:i];
                [self.tempAlapter removeObjectAtIndex:i];
                i--;
            }
        }
        [self.tableView reloadData];

    }];
    NSArray *communtityArr = @[
                              @{
                                  @"xqid": @"11",
                                  @"xqname": @"龙跃小区",
                                  @"pyname": @"lyxq",
                                  @"requrl": @" http://www.baidu.com/t?id=11"
                              },
                              @{
                                  @"xqid": @"12",
                                  @"xqname": @"万龙社区",
                                  @"pyname": @"wlxq",
                                  @"requrl": @"http://www.baidu.com/t?id=11"
                                  },
                              @{
                                  @"xqid": @"13",
                                  @"xqname": @"金龙湾小区",
                                  @"pyname": @"jlyxq",
                                  @"requrl": @" http://www.baidu.com/t?id=11"
                                  },
                              @{
                                  @"xqid": @"13",
                                  @"xqname": @"永泰庄社区",
                                  @"pyname": @"ytzxq",
                                  @"requrl": @" http://www.baidu.com/t?id=11"
                                  }
                              ];
  
//    for (NSDictionary *temp in communtityArr) {
//        LocationModel *model = [[LocationModel alloc] initWithDictionary:temp];
//        [tempCom addObject:model];
//    }
   
    
    NSArray *nearArr = @[
                         @{
                             @"xqid": @"11",
                             @"xqname": @"清河小区",
                             @"pyname": @"qhxq",
                             @"requrl": @" http://www.baidu.com/t?id=11"
                             },
                         @{
                             @"xqid": @"12",
                             @"xqname": @"回龙观社区",
                             @"pyname": @"hlgxq",
                             @"requrl": @" http://www.baidu.com/t?id=11"
                             },
                         @{
                             @"xqid": @"13",
                             @"xqname": @"清园里小区",
                             @"pyname": @"qylxq",
                             @"requrl": @" http://www.baidu.com/t?id=11"
                             },
                         @{
                             @"xqid": @"13",
                             @"xqname": @"永泰庄社区",
                             @"pyname": @"ytzxq",
                             @"requrl": @" http://www.baidu.com/t?id=11"
                             }
                         ];
    NSMutableArray *temNear = [NSMutableArray arrayWithCapacity:0];
    for (NSDictionary *temp in nearArr) {
        LocationModel *model = [[LocationModel alloc] initWithDictionary:temp];
        [temNear addObject:model];
    }


    self.nearArr = [[AlphabetSort returnSortArr:temNear] mutableCopy];
#warning message
    NSLog(@"%@",self.communtityArr);
    }
-(void)viewDidAppear:(BOOL)animated{
    [self makeNav];
    
}
-(void)makeNav{
    [self setNavBarImage:@"landi.png"];
    //[self setBackgroud:@"lantiao x.png"];
    [self setBackImageStateName:@"fanhuijian02.png" AndHighlightedName:@""];


    
    UIView *view = [[UIView alloc] initWithFrame:CGRectZero];
    //view.backgroundColor = MAINVIEWNAVBARCOLOR;
    //[self.view addSubview:view];
    
    UILabel *lable = [[UILabel alloc] initWithFrame:CGRectZero];
    lable.text = @"北京";
    lable.font = [UIFont systemFontOfSize:16 * self.numSingleVesion];
    lable.textColor = [UIColor whiteColor];
    [lable sizeToFit];
    lable.frame = CGRectMake(5 * self.numSingleVesion, 0 + (44 - 15) / 2, lable.frame.size.width, 15);
    [view addSubview:lable];
    view.frame = CGRectMake(0, 0, lable.frame.size.width, 44);
    //UIBarButtonItem *centerBar = [[UIBarButtonItem alloc] initWithCustomView:view];
    self.navigationItem.titleView = view;
    
    
    
    UIButton *pullDown = [UIButton buttonWithType:UIButtonTypeCustom];
    pullDown.frame = CGRectMake(WIDTH_CONTROLLER - 50 * self.numSingleVesion, (44 - 15) / 2, 40 * self.numSingleVesion, 15);
    [pullDown setTitle:@"更换城市" forState:UIControlStateNormal];
    [pullDown addTarget:self action:@selector(navBtnDown) forControlEvents:UIControlEventTouchUpInside];
    [pullDown.titleLabel setTextColor:[UIColor whiteColor]];
    [pullDown.titleLabel sizeToFit];
    pullDown.titleLabel.font = [UIFont systemFontOfSize:16 * self.numSingleVesion];
    pullDown.tag = 1000;
    pullDown.frame = CGRectMake(WIDTH_CONTROLLER - 5 * self.numSingleVesion - pullDown.titleLabel.frame.size.width, (44 - 15) / 2, pullDown.titleLabel.frame.size.width, 15);
    UIBarButtonItem *rightBar = [[UIBarButtonItem alloc] initWithCustomView:pullDown];
    self.navigationItem.rightBarButtonItem = rightBar;
}
-(void)navBtnDown{
    //更换城市
    SelectCityViewController *selectView = [[SelectCityViewController alloc] init];
    [self.navigationController pushViewController:selectView animated:YES];
    
}
-(void)makeUI{
    [self makeCityName];
    [self makeTable];
}
-(void)makeCityName{
    NSArray *cityArr = @[@"本市小区",@"附近小区"];
    for (NSInteger i = 0; i < cityArr.count; i++) {
        UIButton *cityBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        cityBtn.frame = CGRectMake(WIDTH_CONTROLLER / 2 * i, 64, WIDTH_CONTROLLER / 2, 40 * self.numSingleVesion);
        [cityBtn setTitle:cityArr[i] forState:UIControlStateNormal];
        [cityBtn addTarget:self action:@selector(cityDown:) forControlEvents:UIControlEventTouchUpInside];
        cityBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        
        if(i == 0){
            [cityBtn setTitleColor:COMMUNITYNAMECOLOR forState:UIControlStateNormal];
        }else{
            [cityBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
        cityBtn.tag = 1400 + i;
        [self.view addSubview:cityBtn];
    }
    UIImageView *tempImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 64 + 40 * self.numSingleVesion, WIDTH_CONTROLLER, 2)];
    tempImg.image = [UIImage imageNamed:@"line.png"];
    [self.view addSubview:tempImg];
    
    UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(0, 64 + 40 * self.numSingleVesion, WIDTH_CONTROLLER / 2, 2)];
    lable.backgroundColor = [UIColor colorWithRed:(CGFloat)67 / 255.0 green:(CGFloat)142 / 255.0 blue:(CGFloat)185 / 255.0 alpha:1];
    [self.view addSubview:lable];
    self.lineLable = lable;
    
    CGFloat height = [VersionTranlate returnImageHeightImgname:@"searchkuang.png" andWidth:WIDTH_CONTROLLER - 30 * self.numSingleVesion];
    UIImageView *textImg = [[UIImageView alloc] initWithFrame:CGRectMake(15 * self.numSingleVesion, 64 + 40 * self.numSingleVesion + 10, WIDTH_CONTROLLER - 30 * self.numSingleVesion, height)];
    textImg.image = [UIImage imageNamed:@"searchkuang.png"];
    textImg.userInteractionEnabled = YES;
    [self.view addSubview:textImg];
    
//    //输入框
    UITextField *text = [[UITextField alloc] initWithFrame:CGRectMake(25 * self.numSingleVesion, 0, textImg.frame.size.width - 25 * self.numSingleVesion, textImg.frame.size.height)];
    text.placeholder = @"请输入小区名或拼音首字母";
    text.clearButtonMode = UITextFieldViewModeAlways;
    text.borderStyle = UITextBorderStyleNone;
    text.delegate = self;
    [textImg addSubview:text];
   
    
    //目前高度
    self.allHieght = 64 + 40 * self.numSingleVesion + 10 + height + 5 * self.numSingleVesion;
}
-(void)cityDown:(UIButton *)cityBtn{
    for (NSInteger i = 0; i < 2; i++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag:1400 + i];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    [self.dataArr removeAllObjects];
    if (cityBtn.tag == 1400) {
        self.dataArr = [self.communtityArr mutableCopy];
    }else{
        self.dataArr = [self.nearArr mutableCopy];
    }
    [self.tempAlapter removeAllObjects];
    self.tempAlapter = [self.alapterArr mutableCopy];
    for (NSInteger i = 0; i < self.dataArr.count; i++) {
        if ([self.dataArr[i] count] == 0) {
            [self.dataArr removeObjectAtIndex:i];
            [self.tempAlapter removeObjectAtIndex:i];
            i--;
        }
    }

    self.lineLable.frame = CGRectMake(WIDTH_CONTROLLER / 2 * (cityBtn.tag - 1400), 64 + 40 * self.numSingleVesion, WIDTH_CONTROLLER / 2, 2);
    [cityBtn setTitleColor:COMMUNITYNAMECOLOR forState:UIControlStateNormal];
    [self.tableView reloadData];
}
-(void)makeTable{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, self.allHieght, WIDTH_CONTROLLER, HEIGHT_CONTROLLER - self.allHieght) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];
    tableView.showsVerticalScrollIndicator = NO;
    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:COMMUNITYLOCATIONCELL];
    self.tableView = tableView;
    
    
    UITableView *searchTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, self.allHieght, WIDTH_CONTROLLER, HEIGHT_CONTROLLER - self.allHieght) style:UITableViewStylePlain];
    searchTableView.showsVerticalScrollIndicator = NO;
    searchTableView.dataSource = self;
    searchTableView.delegate = self;
    [self.view addSubview:searchTableView];
    [searchTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:COMMUNITYSEARCHCELL];
    searchTableView.hidden = YES;
    self.searchTableView = searchTableView;
    
}
#pragma mark tableview的协议代理
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == self.tableView) {
         return [self.dataArr[section] count];
    }else{
        return self.searchArr.count;
    }
   
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (tableView == self.tableView) {
        return self.dataArr.count;
    }
    else{
        return 1;
    }
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (tableView == self.tableView) {
        return self.tempAlapter[section];
    }
    return nil;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LocationModel *model = nil;
    UITableViewCell *cell = nil;
    if (tableView == self.tableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:COMMUNITYLOCATIONCELL forIndexPath:indexPath];
        model = self.dataArr[indexPath.section][indexPath.row];
    }
    else{
        cell = [tableView dequeueReusableCellWithIdentifier:COMMUNITYSEARCHCELL forIndexPath:indexPath];
        
        model = self.searchArr[indexPath.row];
    }
    cell.textLabel.text = model.xqname;
    return cell;
}
#pragma mark 数组索引
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    NSMutableArray *temp = [NSMutableArray arrayWithCapacity:0];
    if (self.tableView == tableView) {
        for (int i = 'A'; i <= 'Z' ; i++) {
            [temp addObject:[NSString stringWithFormat:@"%c",i]];
        }
        return temp;
    }
    return nil;
}
-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index{
    if (self.tableView == tableView) {
         return index;
    }
    return 0;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.tableView == tableView) {
        LocationModel *model = self.dataArr[indexPath.section][indexPath.row];
        if ([self.target isKindOfClass:[ViewController class]]) {
            [self.target returnCommuityId:model.xqid];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }else{
        
    }
}
#pragma mark textfield的协议代理
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    if(textField.text.length == 0){
        self.tableView.hidden = NO;
        self.searchTableView.hidden = YES;
         [self.tableView reloadData];
        return YES;
    }
    NSMutableArray *searchArr = [NSMutableArray arrayWithCapacity:0];
    for (NSInteger i = 0; i < self.dataArr.count; i++) {
        for (NSInteger j = 0; j < [self.dataArr[i] count]; j++) {
            LocationModel *model = self.dataArr[i][j];
            if (model.xqname.length >= textField.text.length && model.pyname.length >= textField.text.length) {
                if ([[model.xqname substringToIndex:textField.text.length] containsString:textField.text] || [[model.pyname substringToIndex:textField.text.length]containsString:[textField.text uppercaseString]] || [[model.pyname substringToIndex:textField.text.length]containsString:[textField.text lowercaseString]]) {
                    [searchArr addObject:model];
                }
            }

        }
        
        
        
    }
    self.searchArr = searchArr;
    self.tableView.hidden = YES;
    self.searchTableView.hidden = NO;
    [self.searchTableView reloadData];

    
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
