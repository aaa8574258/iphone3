//
//  BaseView.h
//  XiaomiIOs
//
//  Created by linghang on 15-3-12.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIButton+WebCache.h"
#import "UIImageView+WebCache.h"
#import "VersionTranlate.h"
#import "TranlateTime.h"
@interface BaseView : UIView
@property(nonatomic,assign)CGFloat numSingleVesion;
@property(nonatomic,assign)id target;
@end
