//
//  MainBottomView.h
//  360du
//
//  Created by linghang on 15-4-11.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseView.h"

@interface MainBottomView : BaseView
@property(nonatomic,strong)NSArray *imgArr;
@property(nonatomic,strong)NSArray *titleArr;
@property(nonatomic,copy)NSString *bgImg;
@property(nonatomic,strong)NSArray *lightArr;
-(id)initWithFrame:(CGRect)frame andImgArr:(NSArray *)imgArr andTitleArr:(NSArray *)titleArr andBgImg:(NSString *)bgImg andHeilightImg:(NSArray *)linghtImg;
@end
