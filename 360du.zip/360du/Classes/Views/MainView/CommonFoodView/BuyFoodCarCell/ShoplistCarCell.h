//
//  ShoplistCarCell.h
//  360du
//
//  Created by linghang on 15/7/6.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseTableViewCell.h"
@class ShoplistModel;
@interface ShoplistCarCell : BaseTableViewCell

-(void)refreshModel:(ShoplistModel *)model;
@end
