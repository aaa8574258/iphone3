//
//  ShopListView.m
//  360du
//
//  Created by linghang on 15/7/6.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "ShopListView.h"
@interface ShopListView()
@property(nonatomic,strong)NSArray *priceArr;
@end
@implementation ShopListView
-(id)initWithFrame:(CGRect)frame andArr:(NSArray *)priceArr{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}
-(void)makeUI{
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    [self addSubview:scrollView];
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.contentSize = CGSizeMake(WIDTH_VIEW, 200 * self.numSingleVesion);
    for (NSInteger i = 0; i < 4; i++) {
        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(0, 50 * i * self.numSingleVesion, WIDTH_VIEW, 50)];
        [scrollView addSubview:lable];
        if (i % 2 == 0) {
            lable.backgroundColor = [UIColor redColor];
        }else{
            lable.backgroundColor = [UIColor purpleColor];
        }
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
