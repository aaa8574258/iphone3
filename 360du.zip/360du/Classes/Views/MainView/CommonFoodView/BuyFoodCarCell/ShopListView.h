//
//  ShopListView.h
//  360du
//
//  Created by linghang on 15/7/6.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseView.h"

@interface ShopListView : BaseView
-(id)initWithFrame:(CGRect)frame andArr:(NSArray *)priceArr;
@end
