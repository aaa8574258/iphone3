//
//  CommonFoodMerchatListCell.m
//  360du
//
//  Created by linghang on 15/5/16.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "CommonFoodMerchatListCell.h"
#import "UIImageView+WebCache.h"
#import "FoodMerchatListModel.h"
#import "CommonBusinessListCollectionViewCell.h"
@interface CommonFoodMerchatListCell()
@property(nonatomic,strong)UIImageView *leftImg;
@property(nonatomic,strong)UILabel *nameLable;
@property(nonatomic,strong)UILabel *sellNum;
@property(nonatomic,strong)UILabel *priceLable;
@property(nonatomic,strong)UIButton *addBtn;
@property(nonatomic,strong)UIButton *reduceBtn;
@property(nonatomic,strong)UILabel *buyCount;
@end
@implementation CommonFoodMerchatListCell
//-(id)initWithFrame:(CGRect)frame{
//    self = [super initWithFrame:frame];
//    if (self) {
//        [self makeUI];
//    }
//    return self;
//}
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self makeUI];
    }
    return self;
}
-(void)makeUI{
    //左边图片
    self.leftImg = [[UIImageView alloc] initWithFrame:CGRectMake(10 * self.numSingleVersion, 10 * self.numSingleVersion, 80 * self.numSingleVersion, 60 * self.numSingleVersion)];
    [self.contentView addSubview:self.leftImg];
    //食物名称
    self.nameLable = [[UILabel alloc] initWithFrame:CGRectMake(100 * self.numSingleVersion, 10 * self.numSingleVersion, self.allWidth - 100 * self.numSingleVersion - 100 * self.numSingleVersion, 15 * self.numSingleVersion)];
    self.nameLable.font = [UIFont systemFontOfSize:15];
    self.nameLable.textColor = [UIColor blackColor];
    [self.contentView addSubview:self.nameLable];
    //销售几份
    self.sellNum = [[UILabel alloc] initWithFrame:CGRectMake(100 * self.numSingleVersion, 30 * self.numSingleVersion, self.allWidth - 100 * self.numSingleVersion - 100 * self.numSingleVersion, 15 * self.numSingleVersion)];
    self.sellNum.textColor = SMSColor(160, 160, 160);
    [self.contentView addSubview:self.sellNum];
    self.sellNum.font = [UIFont systemFontOfSize:13];
    //价格
    self.priceLable = [[UILabel alloc] initWithFrame:CGRectMake(100 * self.numSingleVersion, 50 * self.numSingleVersion, 50 * self.numSingleVersion, 15 * self.numSingleVersion)];
    self.priceLable.textColor = [UIColor lightGrayColor];
    [self.contentView addSubview:self.priceLable];
    self.priceLable.font = [UIFont systemFontOfSize:13];

    //添加
    self.addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.addBtn.frame = CGRectMake(self.allWidth - 100 * self.numSingleVersion - 30 * self.numSingleVersion, 50 * self.numSingleVersion, 20 * self.numSingleVersion, 20 * self.numSingleVersion);
    [self.addBtn setImage:[UIImage imageNamed:@"加.png"] forState:UIControlStateNormal];
    [self.contentView addSubview:self.addBtn];
    [self.addBtn addTarget:self action:@selector(addBtnDwon:) forControlEvents:UIControlEventTouchUpInside];
    self.addBtn.layer.cornerRadius = 10 * self.numSingleVersion;
    self.addBtn.layer.borderWidth = 1 * self.numSingleVersion;
    self.addBtn.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    //减少
    self.reduceBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.reduceBtn.frame = CGRectMake(self.allWidth - 100 * self.numSingleVersion - 30 * self.numSingleVersion - 10 * self.numSingleVersion - 20 * self.numSingleVersion, 50 * self.numSingleVersion, 20 * self.numSingleVersion, 20 * self.numSingleVersion);
    [self.reduceBtn setImage:[UIImage imageNamed:@"减.png"] forState:UIControlStateNormal];
    [self.contentView addSubview:self.reduceBtn];
    [self.reduceBtn addTarget:self action:@selector(addBtnDwon:) forControlEvents:UIControlEventTouchUpInside];
    self.reduceBtn.layer.cornerRadius = 10 * self.numSingleVersion;
    self.reduceBtn.layer.borderWidth = 1 * self.numSingleVersion;
    self.reduceBtn.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    //买几个
    self.buyCount = [[UILabel alloc] initWithFrame:CGRectMake(self.allWidth - 100 * self.numSingleVersion - 30 * self.numSingleVersion - 10 * self.numSingleVersion, 55 * self.numSingleVersion, 10 * self.numSingleVersion, 10 * self.numSingleVersion)];
    self.buyCount.font = [UIFont systemFontOfSize:13];
    self.buyCount.text = @"0";
    [self.contentView addSubview:self.buyCount];
    self.buyCount.textColor = [UIColor blackColor];
    [self.buyCount sizeToFit];
    self.buyCount.center = CGPointMake(self.allWidth - 100 * self.numSingleVersion - 30 * self.numSingleVersion - 5 * self.numSingleVersion, 60 * self.numSingleVersion);
    
}
-(void)addBtnDwon:(UIButton *)addBtn{
    if ([self.target isKindOfClass:[CommonBusinessListCollectionViewCell class]]) {
        if ([addBtn isEqual:self.addBtn]) {
            
            NSLog(@"secion:%ld",addBtn.tag);
            NSInteger section = (addBtn.tag - 10000) / 1000;
            NSInteger number = (addBtn.tag - 10000) - section * 1000;
#warning message
            NSLog(@"secion:%ld number:%ld",section,number);
            self.buyCount.text = [NSString stringWithFormat:@"%ld",self.buyCount.text.integerValue + 1];
            [self.target returnAddBtn:number andSection:section andAddAndReduce:@"1"];
        }else{
            if (self.buyCount.text.integerValue != 0) {
                self.buyCount.text = [NSString stringWithFormat:@"%ld",self.buyCount.text.integerValue - 1];
                NSInteger section = (addBtn.tag - 20000) / 1000;
                NSInteger number = (addBtn.tag - 20000) - section * 1000;
                [self.target returnAddBtn:number andSection:section andAddAndReduce:@"-1"];
            }
        }
    }
}
-(void)refeshModel:(FoodMerchatListItemModel *)model andNum:(NSInteger)num andSection:(NSInteger)section{
    [self.leftImg sd_setImageWithURL:[NSURL URLWithString:model.imgurl] placeholderImage:[UIImage imageNamed:@"商家底图"]];
    self.nameLable.text = model.name;
    self.sellNum.text = [NSString stringWithFormat:@"已售%@份     推荐%@份",model.sendCount,model.tuijianCount];
    self.priceLable.text = [NSString stringWithFormat:@"￥%@",model.price];
    self.addBtn.tag = 10000 + 1000 * section + num;
    self.reduceBtn.tag = 20000 + 1000 * section + num;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
