//
//  CommonFoodFourBtnHead.h
//  360du
//
//  Created by linghang on 15/5/17.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseView.h"

@interface CommonFoodFourBtnHead : BaseView
-(id)initWithFrame:(CGRect)frame andNSArray:(NSArray *)dataArr andNum:(NSInteger)num;
@end
