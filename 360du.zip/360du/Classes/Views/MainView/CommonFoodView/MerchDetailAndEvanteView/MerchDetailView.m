//
//  MerchDetailView.m
//  360du
//
//  Created by linghang on 15/7/4.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "MerchDetailView.h"

@implementation MerchDetailView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
