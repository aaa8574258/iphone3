//
//  CommonFoodViewController.h
//  360du
//
//  Created by linghang on 15-4-18.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseViewController.h"
@class CommomFoodModel;
@interface CommonFoodViewController : BaseViewController
-(void)refreshUI:(CommomFoodModel *)model;
@end
