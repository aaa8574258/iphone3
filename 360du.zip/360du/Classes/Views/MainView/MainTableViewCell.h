//
//  MainTableViewCell.h
//  360du
//
//  Created by linghang on 15-4-11.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseTableViewCell.h"

@interface MainTableViewCell : BaseTableViewCell

@end
