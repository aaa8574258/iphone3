//
//  SelectCityModel.m
//  360du
//
//  Created by linghang on 15-4-18.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "SelectCityModel.h"

@implementation SelectCityModel

@end
