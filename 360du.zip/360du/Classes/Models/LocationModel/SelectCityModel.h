//
//  SelectCityModel.h
//  360du
//
//  Created by linghang on 15-4-18.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseModel.h"

@interface SelectCityModel : BaseModel
@property(nonatomic,copy)NSString *id;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *pyname;
@property(nonatomic,copy)NSString *requrl;
@end
