//
//  LocationModel.m
//  360du
//
//  Created by linghang on 15-4-12.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "LocationModel.h"

@implementation LocationModel

@end
