//
//  LocationModel.h
//  360du
//
//  Created by linghang on 15-4-12.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseModel.h"

@interface LocationModel : BaseModel
@property(nonatomic,copy)NSString *xqid;
@property(nonatomic,copy)NSString *xqname;
@property(nonatomic,copy)NSString *pyname;
@property(nonatomic,copy)NSString *requrl;
@end
