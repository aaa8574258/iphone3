//
//  FoodMerchatListModel.m
//  360du
//
//  Created by linghang on 15/5/16.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "FoodMerchatListModel.h"

@implementation FoodMerchatListModel

@end
@implementation FoodMerchatListItemModel



@end