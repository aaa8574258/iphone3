//
//  ShoplistModel.m
//  360du
//
//  Created by linghang on 15/7/10.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "ShoplistModel.h"

@implementation ShoplistModel

@end
