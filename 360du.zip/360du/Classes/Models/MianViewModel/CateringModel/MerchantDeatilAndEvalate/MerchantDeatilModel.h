//
//  MerchantDeatilModel.h
//  360du
//
//  Created by linghang on 15/7/4.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseModel.h"

@interface MerchantDeatilModel : BaseModel
@property(nonatomic,copy)NSString *clientlogo;
@property(nonatomic,copy)NSString *shopname;
@property(nonatomic,copy)NSString *companyaddress;
@property(nonatomic,copy)NSString *tel;
@property(nonatomic,copy)NSString *sendtime;
@property(nonatomic,copy)NSString *isFu;
@property(nonatomic,copy)NSString *isFa;
@property(nonatomic,copy)NSString *peisong;
@property(nonatomic,copy)NSString *sendPrice;
@property(nonatomic,copy)NSString *startSendPric;
@property(nonatomic,copy)NSString *status;
@property(nonatomic,strong)NSArray *yhdetail;
@end
