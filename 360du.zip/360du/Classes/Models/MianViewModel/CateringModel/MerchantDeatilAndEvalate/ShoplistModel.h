//
//  ShoplistModel.h
//  360du
//
//  Created by linghang on 15/7/10.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "BaseModel.h"
@class FoodMerchatListItemModel;
@interface ShoplistModel : BaseModel
@property(nonatomic,copy)NSString *count;
@property(nonatomic,strong)FoodMerchatListItemModel *model;
@end
