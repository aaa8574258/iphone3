//
//  MerchantDeatilModel.m
//  360du
//
//  Created by linghang on 15/7/4.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "MerchantDeatilModel.h"

@implementation MerchantDeatilModel

@end
