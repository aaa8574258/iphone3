//
//  FoodListCategoryModel.m
//  360du
//
//  Created by linghang on 15/5/17.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "FoodListCategoryModel.h"

@implementation FoodListCategoryModel

@end
