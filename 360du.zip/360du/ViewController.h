//
//  ViewController.h
//  360du
//
//  Created by linghang on 15-4-6.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
//返回底部点击哪一个
-(void)returnBottomTag:(NSInteger)numBottomBtn;
-(void)returnCommuityId:(NSString *)commuityId;//返回小区的Id
@end

