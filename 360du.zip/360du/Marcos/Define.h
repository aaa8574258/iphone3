//
//  Define.h
//  XiaomiIOs
//
//  Created by linghang on 15-3-3.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#ifndef XiaomiIOs_Define_h
#define XiaomiIOs_Define_h
#define WIDTH_CONTROLLER self.view.frame.size.width
#define HEIGHT_CONTROLLER self.view.frame.size.height
#define WIDTH_VIEW self.frame.size.width
#define HEIDHT_VIEW self.frame.size.height
#define EVERYWIDTH @"(self.view.frame.size.width - 10)/%d"
#define WIDTH_CONTENTVIEW self.contentView.frame.size.width
#define HEIGHT_CONTENTVIEW self.contentView.frame.size.height
#endif
