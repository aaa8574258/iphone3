//
//  Interface.h
//  XiaomiIOs
//
//  Created by linghang on 15-3-3.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#ifndef XiaomiIOs_Interface_h
#define XiaomiIOs_Interface_h
#define MAININTERFACE @"http://211.152.8.99/360duang/"
//获取城市接口
#define GAINCITY MAININTERFACE@"city.json"
//主界面
#define MAINUIDATA MAININTERFACE@"360du/menu.html"
//小区数据
//&cityName=北京市&location=116.459776,39.869331&gotoPage=1&pageSize=4
#define COMMUNITYDATA MAININTERFACE@"serviceServlet?serviceName=findmap&medthodName=xqlist&cityName=%@&location=%@"
//商家列表
#define MERCHANTLIST MAININTERFACE@"serviceServlet?serviceName=dlshopmag&medthodName=dlshoplist&codename=%@&xqid=%ld&sort=%ld&gotoPage=%ld&pageSize=%ld"
//商家列表4个btn按钮
//分类
#define MERCHANTLISTCATEGORY MAININTERFACE@"/serviceServlet?serviceName=dlshopmag&medthodName=prosc&scname=2"
//排序
#define MERCHANTLISTSORT MAININTERFACE@"360du/sort.json"
//福利
#define MERCHANTLISTWELFARE MAININTERFACE@"/serviceServlet?serviceName=dlshopmag&medthodName=profili"
//商家详情
#define MERCHANTLISTDEATIL MAININTERFACE@"/serviceServlet?serviceName=dlshopmag&medthodName=zddlmagTail&DID=%@"
//#define MERCHANTLISTCOMMUNITYDATA MAININTERFACE@"/serviceServlet?serviceName=dlshopmag&medthodName=prosc&scname=1"
#endif
