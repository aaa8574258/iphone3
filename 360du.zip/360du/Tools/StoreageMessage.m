//
//  StoreageMessage.m
//  XiaomiIOs
//
//  Created by linghang on 15-3-20.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "StoreageMessage.h"

@implementation StoreageMessage
+(BOOL)isStoreMessage{
    NSString *username = [[NSUserDefaults standardUserDefaults] objectForKey:@"username"];
    if (username.length != 0) {
        return YES;
    }
    return NO;
}
+(void)storeMessageUsername:(NSString *)username andPassword:(NSString *)password andToken:(NSString *)token{
    [[NSUserDefaults standardUserDefaults] setObject:username forKey:@"username"];
    [[NSUserDefaults standardUserDefaults] setObject:password forKey:@"password"];
    [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"token"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+(NSArray *)getMessage{
    NSString *username = [[NSUserDefaults standardUserDefaults] objectForKey:@"username"];
    NSString *password = [[NSUserDefaults standardUserDefaults] objectForKey:@"password"];
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    return @[username,password,token];
}
@end
