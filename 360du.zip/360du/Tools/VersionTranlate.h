//
//  VersionTranlate.h
//  XiaomiIOs
//
//  Created by linghang on 15-3-10.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VersionTranlate : NSObject
//根据是iphone6
+(CGFloat )returnWidth;
+(CGFloat)returnHeight;
//返回图片的相对高度
+(CGFloat)returnImageHeightImgname:(NSString*)stringName andWidth:(CGFloat)width;
//根据是iphone6p
+(CGFloat)returnIphone6PVersionRate;
//根据是iPhone5
+(CGFloat)returnIphone5AndIphone4PVersionRate;
//返回具体的比例
+(CGFloat)returnVersionRateAnyIphone:(NSInteger)phoneNum;
@end
