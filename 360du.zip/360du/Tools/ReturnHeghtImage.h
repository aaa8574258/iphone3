//
//  ReturnHeghtImage.h
//  MBXiaoYuanProject
//
//  Created by linghang on 15-1-27.
//  Copyright (c) 2015年 linghang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ReturnHeghtImage : NSObject
+(CGFloat)imageHeight:(NSInteger)height andWidth:(NSInteger)allWidth;
+(CGFloat)returnNSStringHeight:(NSString *)str andFont:(NSInteger)font andWidth:(CGFloat)width;
@end
