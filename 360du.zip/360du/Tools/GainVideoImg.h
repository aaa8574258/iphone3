//
//  GainVideoImg.h
//  XiaomiIOs
//
//  Created by linghang on 15-3-31.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>
//获取视频帧的图像
@interface GainVideoImg : NSObject
+(UIImage *)gainImg:(NSString *)url andWidth:(CGFloat)width andHeight:(CGFloat)height;
@end
