//
//  TranlateTime.h
//  MBXiaoYuanProject
//
//  Created by linghang on 15-1-21.
//  Copyright (c) 2015年 linghang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TranlateTime : NSObject
+(NSString *)tranlayeTime:(NSString *)time;
+(NSString *)returnNowYear;
+(NSString *)tranlayeNewStyleTime:(NSString *)time;
+(NSString *)tranlayeYearMothDateTime:(NSString *)time;
+(NSString *)jugeCourseIsOnCourseStartDate:(NSString *)startDate andEndDate:(NSString *)endDate;//判断该课程有没有开课，0代表未开课，1代表开课，2代表结束课程
@end
