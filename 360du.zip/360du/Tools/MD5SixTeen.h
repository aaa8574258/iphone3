//
//  MD5SixTeen.h
//  MBXiaoYuanProject
//
//  Created by linghang on 15-1-21.
//  Copyright (c) 2015年 linghang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MD5SixTeen : NSObject
+(NSString *)md5:(NSString *)input;
@end
