//
//  StoreageMessage.h
//  XiaomiIOs
//
//  Created by linghang on 15-3-20.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StoreageMessage : NSObject
+(BOOL)isStoreMessage;
+(void)storeMessageUsername:(NSString *)username andPassword:(NSString *)password andToken:(NSString *)token;
+(NSArray *)getMessage;
@end
