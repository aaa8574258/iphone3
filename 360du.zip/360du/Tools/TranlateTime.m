//
//  TranlateTime.m
//  MBXiaoYuanProject
//
//  Created by linghang on 15-1-21.
//  Copyright (c) 2015年 linghang. All rights reserved.
//

#import "TranlateTime.h"

@implementation TranlateTime
+(NSString *)tranlayeTime:(NSString *)time{
    NSDate  *date = [NSDate dateWithTimeIntervalSince1970:time.floatValue];
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate: date];
    NSDate *localeDate = [date  dateByAddingTimeInterval: interval];
    NSDateFormatter *formater  = [[NSDateFormatter alloc] init];
    [formater setDateFormat:@"yyyy-MM-dd"];
    NSString *formatDate = [formater stringFromDate:localeDate];
    return formatDate;
}
+(NSString *)returnNowYear{
    NSDate *date1 = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy"];
    NSString *formatDate = [formatter stringFromDate:date1];
    return formatDate;
}
+(NSString *)tranlayeNewStyleTime:(NSString *)time{
    NSDate  *date = [NSDate dateWithTimeIntervalSince1970:time.floatValue];
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate: date];
    NSDate *localeDate = [date  dateByAddingTimeInterval: interval];
    NSDateFormatter *formater  = [[NSDateFormatter alloc] init];
    [formater setDateFormat:@"yy/MM/dd"];
    NSString *formatDate = [formater stringFromDate:localeDate];
    return formatDate;
}
+(NSString *)tranlayeYearMothDateTime:(NSString *)time{
    NSDate *todayDate = [NSDate date];
    NSDate  *date = [NSDate dateWithTimeIntervalSince1970:time.floatValue];
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate: date];
    NSDate *localeDate = [date  dateByAddingTimeInterval: interval];
    NSDateFormatter *formater  = [[NSDateFormatter alloc] init];
    [formater setDateFormat:@"yyMMdd"];
    NSString *formatDate = [formater stringFromDate:localeDate];
    NSString *formatTodayDate = [formater stringFromDate:todayDate];
    if (formatDate.integerValue > formatTodayDate.integerValue) {
        return @"1";
    }
    return @"0";
}
+(NSString *)jugeCourseIsOnCourseStartDate:(NSString *)startDate andEndDate:(NSString *)endDate{
    if ([[TranlateTime tranlayeNewStyleTime:startDate] isEqualToString:@"0"]) {
        if ([[TranlateTime tranlayeNewStyleTime:endDate] isEqualToString:@"0"]) {
            return @"2";
        }
        return @"1";
    }
    return @"0";
}
@end
