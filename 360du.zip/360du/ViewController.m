//
//  ViewController.m
//  360du
//
//  Created by linghang on 15-4-6.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import "ViewController.h"
#import "VersionTranlate.h"
#import "MainTableViewCell.h"
#import "MainBottomView.h"
#import "MainViewLoadData.h"
#import "MainModel.h"
#import "LocationCommunityViewController.h"
#import "SearchViewController.h"
#import "FoodCommonViewController.h"
#import "GainLocationLatiguateAndLongtitute.h"
#import "AFNetworkTwoPackaging.h"
#import "FileOperation.h"
#import "UIButton+WebCache.h"
#import "LocationModel.h"
#import <CoreLocation/CoreLocation.h>
#define MAINVIEWCELL @"mainViewCell"
@interface ViewController ()<UITextFieldDelegate,UIScrollViewDelegate,CLLocationManagerDelegate,MBProgressHUDDelegate>{
CLLocationManager *_locationManager;
}

@property(nonatomic,assign)CGFloat versionTralate;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,weak)UITableView *tableView;
@property(nonatomic,strong)AFHTTPRequestOperationManager *rom;
@property(nonatomic,copy)NSString *communtityId;//小区的Id
@property(nonatomic,strong)MBProgressHUD *hudProgress;
@property(nonatomic,weak)UILabel *commuityName;//小区
@property(nonatomic,copy)NSString *cityName;//城市名称
@property(nonatomic,copy)NSString *latAndlongTitude;//经纬度
@property(nonatomic,strong)NSMutableArray *communtityArr;//经纬度
@end

@implementation ViewController
-(void)viewWillAppear:(BOOL)animated{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@""] forBarMetrics:UIBarMetricsDefault];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    if (self.communtityId.length == 0) {
        self.communtityId = @"123";
    }
    [self makeInit];
    [self laodData];
    [self makeLocation];
    self.versionTralate = [VersionTranlate returnVersionRateAnyIphone:WIDTH_CONTROLLER];
    //self.view.backgroundColor = [UIColor whiteColor];
    [self makeUI];
    [self makeHUd];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)makeInit{
    self.commuityName.text = @"回龙观小区";
    self.cityName = @"北京市";
    self.latAndlongTitude = @"116.453250,39.867688";
    self.communtityArr = [NSMutableArray arrayWithCapacity:0];
}
//加载图片
-(void)makeHUd{
    self.hudProgress = [[MBProgressHUD alloc] initWithView:self.view];
    self.hudProgress.delegate = self;
    //self.hudProgress.color = [UIColor clearColor];
    self.hudProgress.labelText = @"loading";
    self.hudProgress.dimBackground = YES;
    //self.hudProgress.margin = 80.f;
    //self.hudProgress.yOffset = 150.f;
    [self.view addSubview:self.hudProgress];
    [self.hudProgress showWhileExecuting:@selector(myProgressTask) onTarget:self withObject:nil animated:YES];
}


-(void)laodData{
    self.dataArr = [NSMutableArray arrayWithCapacity:0];
    self.rom = [AFHTTPRequestOperationManager manager];
    self.rom.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/json",@"text/html",@"application/json",nil];
    [self.rom GET:MAINUIDATA parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self hudWasHidden:self.hudProgress];
        for (NSDictionary *temp in responseObject) {
            MainModel *model = [[MainModel alloc] initWithDictionary:temp];
            [self.dataArr addObject:model];
        }
        [self makeScrollView];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [[NSURLCache sharedURLCache] removeAllCachedResponses];
        [self hudWasHidden:self.hudProgress];
//        NSLog(@"%@",[error description]);
//        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"警告" message:@"网络不流畅，请换个网络试试" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确认", nil];
//        [alertView show];
//        return ;
    }];

}
-(void)makeUI{
    [self makeNav];
    [self makeTitleImg];
    //[self makeScrollView];
    [self makeBottom];
    
}

//导航条
-(void)makeNav{
    UIView *view = [[UIView alloc] initWithFrame:CGRectZero];
    //view.backgroundColor = MAINVIEWNAVBARCOLOR;
    //[self.view addSubview:view];
    
    UILabel *lable = [[UILabel alloc] initWithFrame:CGRectZero];
    lable.text = @"回龙观小区";
    lable.font = [UIFont systemFontOfSize:16 * self.versionTralate];
    lable.textColor = MAINVIEWADDRESSCOLOR;
    [lable sizeToFit];
    lable.frame = CGRectMake(5 * self.versionTralate, 0 + (44 - 15) / 2, lable.frame.size.width, 15);
    [view addSubview:lable];
    view.frame = CGRectMake(0, 0, lable.frame.size.width, 44);
    self.commuityName = lable;
    
    UIBarButtonItem *left1 = [[UIBarButtonItem alloc] initWithCustomView:view];
    
    UIButton *pullDown = [UIButton buttonWithType:UIButtonTypeCustom];
    pullDown.frame = CGRectMake(15 * self.versionTralate + lable.frame.size.width, 20 + (44 - 15) / 2, 20, 15);
    [pullDown setImage:[UIImage imageNamed:@"sanjiao.png"] forState:UIControlStateNormal];
    [pullDown addTarget:self action:@selector(backDown:) forControlEvents:UIControlEventTouchUpInside];
    pullDown.tag = 1000;
    UIBarButtonItem *left2 = [[UIBarButtonItem alloc] initWithCustomView:pullDown];
    left2.tag = 1100;
    self.navigationItem.leftBarButtonItems = @[left1,left2];
    
    CGFloat height = 150 * self.versionTralate / 606 * 84;
    UIButton *searchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    searchBtn.frame = CGRectMake(WIDTH_CONTROLLER - 160 * self.versionTralate, 20 + (44 - height) / 2, 150 * self.versionTralate, height);
    [searchBtn setImage:[UIImage imageNamed:@"search.png"] forState:UIControlStateNormal];
    [searchBtn addTarget:self action:@selector(backDown:) forControlEvents:UIControlEventTouchUpInside];
    searchBtn.tag = 1001;

    UIBarButtonItem *right1 = [[UIBarButtonItem alloc] initWithCustomView:searchBtn];
    self.navigationItem.rightBarButtonItem = right1;
}
-(void)backDown:(UIBarButtonItem *)navBtn{
    if (navBtn.tag == 1000) {
        LocationCommunityViewController *location = [[LocationCommunityViewController alloc] init];
        location.target = self;
        [self.navigationController pushViewController:location animated:YES];
    }else{
        SearchViewController *search = [[SearchViewController alloc] init];
        [self.navigationController pushViewController:search animated:YES];
    }
}
-(void)makeTitleImg{
    UIImageView *btnImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 64, WIDTH_CONTROLLER, 60 * self.versionTralate)];
    btnImg.image = [UIImage imageNamed:@"landi.png"];
    [self.view addSubview:btnImg];
    CGFloat imgHeight = [VersionTranlate returnImageHeightImgname:@"wenzi.png" andWidth:WIDTH_CONTROLLER - (10 + 50) * self.versionTralate];
    UIImageView *btnLableImg = [[UIImageView alloc] initWithFrame:CGRectMake(10 * self.versionTralate, (60 - imgHeight) / 2, WIDTH_CONTROLLER - (10 + 50) * self.versionTralate, imgHeight)];
    btnLableImg.image = [UIImage imageNamed:@"wenzi.png"];
    [btnImg addSubview:btnLableImg];
}
//tableview
-(void)makeScrollView{
    UIScrollView *mainScr = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64 + (60 + 30) * self.versionTralate, self.view.frame.size.width, HEIGHT_CONTROLLER - (64 + (60 + 30) * self.versionTralate - 49))];
    mainScr.pagingEnabled = YES;
    mainScr.delegate = self;
    mainScr.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:mainScr];
    CGFloat iconWidth = (WIDTH_CONTROLLER - 10 * self.versionTralate * 3 - 40 * self.versionTralate) / 4;
    CGFloat iconHeight = (iconWidth + 20 + 20 * self.versionTralate);
    if (self.dataArr.count > 12) {
        mainScr.contentSize = CGSizeMake(WIDTH_CONTROLLER * 2, iconHeight * 2 + iconWidth + 20);
        [self makePageContro];
    }else{
        mainScr.contentSize = CGSizeMake(WIDTH_CONTROLLER, iconHeight * 2 + iconWidth + 20);
    }
    for (NSInteger i = 0; i < self.dataArr.count; i++) {
        MainModel *model = self.dataArr[i];
        UILabel *iconTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, 15)];
        iconTitle.text = model.name;
        iconTitle.font = [UIFont systemFontOfSize:14 * self.versionTralate];
        iconTitle.textColor = MAINVIEICONCOLOR;
        [iconTitle sizeToFit];
        [mainScr addSubview:iconTitle];
        iconTitle.center = CGPointMake(20 * self.versionTralate + iconWidth / 2 + (iconWidth + 10 * self.versionTralate ) * (i % 4), iconWidth +  iconHeight * (i / 4) + 10);
        UIButton *iconBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        iconBtn.frame = CGRectMake(20 * self.versionTralate + (iconWidth + 10 * self.versionTralate) * (i % 4) , iconHeight * (i / 3), iconWidth, iconWidth);
        if (i >= 12) {
            iconBtn.center = CGPointMake(20 * self.versionTralate + iconWidth / 2 + (iconWidth + 10 * self.versionTralate ) * (i % 4) + WIDTH_CONTROLLER, iconWidth / 2 +  iconHeight * ((i - 11) / 4));
            iconTitle.center = CGPointMake(20 * self.versionTralate + iconWidth / 2 + (iconWidth + 10 * self.versionTralate ) * (i % 4) + WIDTH_CONTROLLER, iconWidth +  iconHeight * ((i - 11) / 4) + 10);
            
        }else{
            iconBtn.center = CGPointMake(20 * self.versionTralate + iconWidth / 2 + (iconWidth + 10 * self.versionTralate ) * (i % 4), iconWidth / 2 +  iconHeight * (i / 4));
        }
        //MainModel *model = self.dataArr[i];
        [iconBtn sd_setImageWithURL:[NSURL URLWithString:model.indeximg] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"001.png"]];
        [iconBtn addTarget:self action:@selector(scrBtnDown:) forControlEvents:UIControlEventTouchUpInside];
        iconBtn.tag = 1200 + i;
        [mainScr addSubview:iconBtn];
        
        
    }
//    UIPageControl *page = [[UIPageControl alloc] initWithFrame:CGRectMake(0, HEIGHT - 49 - 20, WIDTH, 20)];
//    page.numberOfPages = 2;
//    page.userInteractionEnabled = NO;
//    page.tag = 12000;
//    page.backgroundColor = [UIColor grayColor];
//    [self.view addSubview:page];
}
-(void)makePageContro{
    UIPageControl *pageContro = [[UIPageControl alloc] initWithFrame:CGRectMake(0, HEIGHT_CONTROLLER - 49 * self.versionTralate - 15 * self.versionTralate, WIDTH_CONTROLLER, 10 * self.versionTralate)];
    pageContro.numberOfPages = 2;
    pageContro.pageIndicatorTintColor = [UIColor lightGrayColor];
    pageContro.currentPageIndicatorTintColor = [UIColor blueColor];
    [self.view addSubview:pageContro];
    //pageContro.backgroundColor = [UIColor lightGrayColor];
    pageContro.userInteractionEnabled = NO;
    pageContro.tag = 12000;
    
}
-(void)scrBtnDown:(UIButton *)scrBtn{
    
    MainModel *model = self.dataArr[scrBtn.tag - 1200];
    FoodCommonViewController *common = [[FoodCommonViewController alloc] initWithTitleName:model.name andNSString:model.requrl andCommuntityId:self.communtityId andSortNum:1 andCatergoryId:model.id.integerValue andCommuntityArr:self.communtityArr andLoaction:self.latAndlongTitude andCityName:self.cityName];
    [self.navigationController pushViewController:common animated:YES];
}
//bottom
-(void)makeBottom{
    NSArray *imgArr = @[@"geren01.png",@"dingdan01.png",@"shoucang01.png",@"xiaoxi01.png",@"shezhi01.png"];
    NSArray *lightArr = @[@"geren02.png",@"dingdan02.png",@"shoucang02.png",@"xiaoxi02.png",@"shezhi02.png"];
    NSArray *titleArr = @[@"个人中心",@"订单",@"收藏",@"消息",@"设置"];
    
    MainBottomView *bottomView = [[MainBottomView alloc] initWithFrame:CGRectMake(0, HEIGHT_CONTROLLER - 49 * self.versionTralate, WIDTH_CONTROLLER, 49 * self.versionTralate) andImgArr:imgArr andTitleArr:titleArr andBgImg:@"" andHeilightImg:lightArr];
    bottomView.target = self;
    [self.view addSubview:bottomView];
}
//返回底部点击哪一个
-(void)returnBottomTag:(NSInteger)numbottomBtn{
    switch (numbottomBtn) {
        case 0:{
//            LogInViewController *logIn = [[LogInViewController alloc] init];
//            [self.navigationController pushViewController:logIn animated:YES];
            break;
        }
        case 1:{
            
            break;
        }
        case 2:{
            
            break;
        }
        case 3:{
            
            break;
        }
        case 1904:{
            
            break;
        }
        default:
            break;
    }
}
#pragma mark 返回小区的Id
-(void)returnCommuityId:(NSString *)commuityId{
    self.communtityId = commuityId;
}
#pragma mark 定位
-(void)makeLocation{
    //定位管理器
    _locationManager=[[CLLocationManager alloc]init];
    
    if (![CLLocationManager locationServicesEnabled]) {
        NSLog(@"定位服务当前可能尚未打开，请设置打开！");
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"定位服务当前可能尚未打开，请设置打开!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确认", nil];
        [alertView show];
        [self gainCommuntity];
        return;
    }
    
    //如果没有授权则请求用户授权
    if ([CLLocationManager authorizationStatus]==kCLAuthorizationStatusNotDetermined){
        [_locationManager requestWhenInUseAuthorization];
    }else if([CLLocationManager authorizationStatus]==kCLAuthorizationStatusAuthorizedWhenInUse){
        //设置代理
        _locationManager.delegate=self;
        //设置定位精度
        _locationManager.desiredAccuracy=kCLLocationAccuracyBest;
        //定位频率,每隔多少米定位一次
        CLLocationDistance distance=10.0;//十米定位一次
        _locationManager.distanceFilter=distance;
        //启动跟踪定位
        [_locationManager startUpdatingLocation];
    }
}
#pragma mark - CoreLocation 代理
#pragma mark 跟踪定位代理方法，每次位置发生变化即会执行（只要定位到相应位置）
//可以通过模拟器设置一个虚拟位置，否则在模拟器中无法调用此方法
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations{
    CLLocation *location=[locations firstObject];//取出第一个位置
    CLLocationCoordinate2D coordinate=location.coordinate;//位置坐标
    NSLog(@"经度：%f,纬度：%f,海拔：%f,航向：%f,行走速度：%f",coordinate.longitude,coordinate.latitude,location.altitude,location.course,location.speed);
    NSString *altAndlongitude =  [NSString stringWithFormat:@"%f,%f",coordinate.longitude,coordinate.latitude];
    if (![altAndlongitude isEqualToString:self.latAndlongTitude]) {
        self.latAndlongTitude = altAndlongitude;
    }
    //如果不需要实时定位，使用完即使关闭定位服务
    [_locationManager stopUpdatingLocation];
    [self getAddressByLatitude:coordinate.latitude longitude:coordinate.longitude];
   
}
#pragma mark 根据坐标取得地名
-(void)getAddressByLatitude:(CLLocationDegrees)latitude longitude:(CLLocationDegrees)longitude{
    //反地理编码
    CLLocation *location=[[CLLocation alloc]initWithLatitude:latitude longitude:longitude];
    CLGeocoder *geocoder=[[CLGeocoder alloc]init];
    [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        CLPlacemark *placemark=[placemarks firstObject];
        if (![self.commuityName.text isEqualToString:placemark.addressDictionary[@"SubLocality"]]) {
            self.commuityName.text = placemark.addressDictionary[@"SubLocality"];
            [self gainCommuntity];
        }else{
            [self gainCommuntity];
        }
        if (![self.cityName isEqualToString:placemark.addressDictionary[@"State"]]) {
            self.cityName = placemark.addressDictionary[@"State"];
        }
}];
}-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
#pragma mark 获取附近小区
-(void)gainCommuntity{
    self.rom = [AFHTTPRequestOperationManager manager];
    self.rom.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/json",@"text/html",@"text/plain",@"application/json",nil];
    NSString *url = [[NSString stringWithFormat:COMMUNITYDATA,self.cityName,self.latAndlongTitude] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [self.rom GET: url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {

        [self.communtityArr removeAllObjects];
        for (NSDictionary *temp in responseObject[@"buzdata"]) {
            LocationModel *model = [[LocationModel alloc] initWithDictionary:temp];
            [self.communtityArr addObject:model];
        }
        if ([responseObject[@"buzdata"] count] != 0) {
            self.communtityId = responseObject[@"buzdata"][0][@"xqid"];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
       // [[NSURLCache sharedURLCache] removeAllCachedResponses];
#warning message
        NSLog(@"%@",error);
            }];

}
#pragma mark HUD的代理方法,关闭HUD时执行
-(void)hudWasHidden:(MBProgressHUD *)hud
{
    [hud removeFromSuperview];
    hud = nil;
}
-(void) myProgressTask{
    float progress = 0.0f;
    while (progress < 1.0f) {
        progress += 0.01f;
        self.hudProgress.progress = progress;
        usleep(50000);
    }
    
}
#pragma mark scrollview的delegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger num = scrollView.contentOffset.x / WIDTH_CONTROLLER;
    UIPageControl *pageCon = (UIPageControl *)[self.view viewWithTag:12000];
    pageCon.currentPage = num;
}
#pragma mark 自动旋转
- (BOOL)shouldAutorotate
{
    return YES;
}

- (NSUInteger)supportedInterfaceOrientations
{
    return (UIInterfaceOrientationMaskAll);
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(void)viewWillDisappear:(BOOL)animated{
    //self.navigationController.navigationBarHidden = NO;
   }
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
