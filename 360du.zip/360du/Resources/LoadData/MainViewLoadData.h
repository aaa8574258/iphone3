//
//  MainViewLoadData.h
//  360du
//
//  Created by linghang on 15-4-11.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainViewLoadData : NSObject
//获取首页数据
+(NSArray *)returnMianData;
@end
