//
//  GetSynUrl.h
//  XiaomiIOs
//
//  Created by linghang on 15-3-10.
//  Copyright (c) 2015年 wangjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetSynUrl : NSObject
+(id )returnRequestUrl:(NSString *)url;
@end
